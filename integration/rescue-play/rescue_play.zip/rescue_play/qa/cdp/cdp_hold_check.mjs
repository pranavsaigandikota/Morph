// SUPPLEMENTARY CDP-LEVEL CHECK (Chrome DevTools Protocol Input.dispatchKeyEvent, autoRepeat:false).
// NOT an OS-level keyboard test: no real OS key-repeat is generated.
// Usage: serve rescue_play on :8765 (python3 -m http.server 8765), start
//   google-chrome --headless=new --remote-debugging-port=9333 about:blank
// then: node --experimental-websocket qa/cdp/cdp_hold_check.mjs
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function connect(url) {
  const t = await (await fetch(`http://127.0.0.1:9333/json/new?${encodeURIComponent(url)}`, { method: "PUT" })).json();
  const ws = new WebSocket(t.webSocketDebuggerUrl); let id = 0; const pend = new Map();
  ws.onmessage = (m) => { const d = JSON.parse(m.data); if (pend.has(d.id)) { pend.get(d.id)(d); pend.delete(d.id); } };
  await new Promise((r) => (ws.onopen = r));
  const send = (method, params = {}) => new Promise((r) => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
  const ev = async (expr) => { const r = await send("Runtime.evaluate", { expression: expr, returnByValue: true, awaitPromise: true }); if (!r.result || r.result.exceptionDetails) console.error("EVAL", expr, JSON.stringify(r).slice(0, 300)); return r.result?.result?.value; };
  const key = (type, k) => send("Input.dispatchKeyEvent", { type, key: k, code: k, windowsVirtualKeyCode: { ArrowRight: 39, ArrowLeft: 37, ArrowDown: 40, ArrowUp: 38 }[k], autoRepeat: false });
  await send("Page.bringToFront"); await sleep(1200);
  return { ws, ev, key };
}
const out = {};
{
  const { ws, ev, key } = await connect("http://localhost:8765/qa/cdp/harness.html");
  for (let i = 0; i < 20 && !(await ev("window.ready === true")); i++) await sleep(100);
  // 1) hold Right ~1 s in the open field
  await ev("load('open')");
  await key("keyDown", "ArrowRight"); const t0 = Date.now(); await sleep(1000);
  const atRelease = await ev("info()"); await key("keyUp", "ArrowRight"); const held = Date.now() - t0;
  const afterUp = await ev("info()"); await sleep(1000); const later = await ev("info()");
  out.hold_open = { held_ms: held, at_release: atRelease, right_after_keyup: afterUp, one_second_after_keyup: later };
  // 2) hold Right ~1 s into a wall at [1,2]
  await ev("load('wall')");
  await key("keyDown", "ArrowRight"); await sleep(1000); const w = await ev("info()"); await key("keyUp", "ArrowRight");
  await sleep(600); out.hold_wall = { during: w, after_keyup: await ev("info()") };
  // 3) tap
  await ev("load('open')"); await key("keyDown", "ArrowRight"); await key("keyUp", "ArrowRight"); await sleep(800);
  out.tap = await ev("info()");
  ws.close();
}
{
  const { ws, ev, key } = await connect("http://localhost:8765/demo/index.html");
  const hud = () => ev("document.getElementById('hud').textContent.split('\\n').filter(Boolean).join(' | ')");
  const before = await hud();
  await key("keyDown", "ArrowRight"); await sleep(1000); const during = await hud(); await key("keyUp", "ArrowRight");
  const after = await hud(); await sleep(1000);
  out.demo = { before, during_1s_hold: during, at_keyup: after, one_second_after_keyup: await hud(), scrollY: await ev("window.scrollY") };
  ws.close();
}
console.log(JSON.stringify(out, null, 1));
