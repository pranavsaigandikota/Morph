# @worldshift/rescue-play

A **browser-playable, zero-dependency TypeScript port of the step rules of the frozen
Python `rescue_sim.RescueEnv`**, plus an exact A\* port, a small play layer (restart,
undo, player metrics, game score, A\* comparison), five hand-designed missions and
automated cross-language parity tests.

* ESM, no runtime dependencies, framework independent; runs in any modern browser and in Node ≥ 18.
* Built output is committed in `dist/` (`.js` + `.d.ts`), so a frontend can use it without building.
* The Python simulator (`rescue_sim`) is **not modified** and is only used, read-only, to generate parity fixtures.
* This is a structured grid game/simulator: **no world model, no AI-generated video, no physics.**

## Install

Option A - copy the built files (no tooling needed): copy `dist/` into your app, e.g.
`frontend/src/lib/rescue-play/`, and `import { RescueGame } from "./lib/rescue-play/index.js"`.

Option B - local package: in the frontend, `npm install ../rescue_play` (or add
`"@worldshift/rescue-play": "file:../rescue_play"` to `dependencies`), then
`import { RescueGame } from "@worldshift/rescue-play"`.

Developing this package (Windows or Linux, Node 18+):

```bash
npm ci            # typescript + vitest (dev only)
npm run build     # tsc -> dist/
npm test          # vitest: Python->TS parity fixtures + unit tests
npm run parity    # regenerate fixtures from Python, run both directions (needs Python with rescue_sim)
```

`npm run parity` finds Python via `RESCUE_SIM_PYTHON`, else the sibling
`../rescue_sim/.venv` (`Scripts\python.exe` on Windows, `bin/python` elsewhere), else
`python3` / `python` / `py -3` that can `import rescue_sim`.

## Quick start

```ts
import { RescueGame, keyToAction } from "@worldshift/rescue-play";

const mission = await (await fetch("/data/rescue-play/missions/cypress-lane-flood.json")).json();
const game = new RescueGame(mission);           // validates exactly like Python Scenario.validate
game.step("ArrowRight");                         // or 0-3, "up"/"down"/"left"/"right", "w"/"a"/"s"/"d"
const state = game.getState();                   // same JSON shape as Python env.get_state()
if (game.done) console.log(game.score(), game.compareWithAStar());
game.restart();
```

## API reference

| export | description |
|--------|-------------|
| `RescueEnvTS(scenario, {rewardConfig?, hazardTerminates?=true, maxSteps?})` | exact port of `RescueEnv` step rules. Constructor validates and resets. `reset()`, `step(action) -> {reward, terminated, truncated, info}`, `getState(includeTrajectory=true)`, `getTrajectory()`, `done`, `cumulativeReward`, `trajectory`, `agentPos`, `stepCount`, `collisions`, `outcome` |
| `replayEpisode(actions, scenario, {rewardConfig?, hazardTerminates?})` | exact port of Python `replay_episode` (same output dict) |
| `RescueGame(scenario, opts)` | play layer: `step(actionOrKey)`, `restart()` / `reset()`, `undo()` (play feature), `getState()`, `metrics()`, `score()`, `compareWithAStar()`, `exportReplayInput()`, `history`, `attempts`, `restarts`, `undoCount` |
| `Scenario.fromDict(data, validate=true)` / `Scenario.fromJSON(text)` | load + validate; `validate(requireHazardFreePath)`, `toDict()`, `hasHazardFreePath()`, `inBounds()` |
| `ScenarioError` | thrown with the **same messages** as Python `ScenarioError` |
| `astarPath(scenario, {allowHazards?})` | exact port of `astar_path` (`Cell[]` or `null`) |
| `pathToActions(path)` | port of `path_to_actions` |
| `compareWithAStar(trajectory, scenario)` | `{optimal_length, player_steps, extra_steps, efficiency, success, first_divergence_step, astar_route, player_route, player_positions}` |
| `computeScore(outcome, steps, collisions, astarLen)` / `SCORE_RULES` | game score |
| `parseAction(x)` / `ActionError` | port of `parse_action` (same error messages) |
| `keyToAction(key)` | `ArrowUp/w/KeyW -> 0`, `ArrowDown/s/KeyS -> 1`, `ArrowLeft/a/KeyA -> 2`, `ArrowRight/d/KeyD -> 3`, else `null` |
| `pyRound(x, n)`, `r10(x)` | bit-exact Python `round(x, n)`; `r10` = Python `_r` |
| `ACTIONS`, `ACTION_NAMES`, `COORDINATE_SYSTEM`, `DEFAULT_REWARDS`, `defaultMaxSteps(w, h)` | constants |

## Rules (identical to the frozen Python RescueEnv)

| situation | effect | reward added (default) |
|-----------|--------|------------------------|
| any step | step_count += 1 | `step` -0.1 |
| target out of bounds, wall or blocked | agent stays, step consumed, `collision = true`, `collisions += 1` | `collision` -1.0 |
| target is a hazard | agent moves onto it, `hazard = true`; if `hazard_terminates` (default **true**): `terminated`, outcome `hazard`; else continue | `hazard` -5.0 |
| target is the goal (checked after the hazard check) | `terminated`, outcome `success` | `goal` +10.0 |
| not terminated and `step_count >= max_steps` | `truncated`, outcome `timeout` | - |
| step after `terminated` or `truncated` | throws `Error("episode is over; call reset()")` (checked before action parsing, like Python) | - |
| invalid action | throws `ActionError` with Python's message | - |

Per-step reward = `r10(step + collision? + hazard? + goal?)` (terms added in that order);
`cumulative_reward` is the **unrounded** running sum of the rounded step rewards and is
rounded with `r10` only when reported (`info`, `getState`) - exactly as Python.
Default `max_steps` = Python `int(round(1.5 * w * h))` (150 for 10x10, 96 for 8x8).

## Coordinates

`[x, y]`, origin top-left, x grows right, y grows down, `grid[y][x]`. Actions: `0 up (y-1)`,
`1 down (y+1)`, `2 left (x-1)`, `3 right (x+1)`.

## Scenario format

The existing rescue_sim JSON: `seed, width, height, start, goal, walls, hazards, max_steps`
(required) plus `doors, blocked, version` (optional). Extra keys (e.g. `mission`) are ignored.
Validation = Python `Scenario.from_dict` + `validate`: integer sizes within [5, 64], positive
`max_steps`, integer `[x, y]` cells, no duplicates, everything in bounds, `start != goal`,
start/goal not on walls/blocked/hazards, no overlaps (walls/hazards, walls/blocked,
walls/doors, blocked/hazards, doors/hazards), and a start->goal path avoiding walls and blocked.

## Play layer and score (game-layer metrics, NOT part of the simulator contract)

`metrics()`: `steps, collisions, hazards_entered, outcome, success, failure, timeout,
native_total_reward` (unchanged Python reward), `restarts, undo_count, undo_used, attempt`.

`score()`:

* success: `score = max(0, round(1000 * astar_len / steps) - 50 * collisions)`, where
  `astar_len` = moves on the hazard-avoiding A\* path from the start; efficiency = `astar_len / steps`;
  stars = 3 if efficiency >= 1.0, 2 if >= 0.8, else 1.
* failure (`hazard` or `timeout`): score 0, stars 0, `reason` = outcome.
* in progress: score `null`.

`undo()` is a play feature: it restarts and replays the history minus the last action, and
marks the attempt `undo_used`. `restart()` counts restarts; unfinished attempts are logged in
`attempts` with `ended_by: "restart"`. `exportReplayInput()` returns
`{actions, scenario, hazard_terminates, reward_config}` for Python
`replay_episode(actions, scenario, hazard_terminates=..., reward_config=...)`.

## Missions (`missions/`, frontend copy in `data/rescue-play/`)

Fictional, hand-designed, `handcrafted: true`, seeds 900001-900005 (outside every rescue_sim
seed split). Each is a valid scenario JSON plus a `mission` block (id, title, briefing,
objective, difficulty, legend, par, max_steps, controls, ASCII map, design notes, analysis,
disclaimer). All validated by both Python `Scenario.validate(require_hazard_free_path=True)` and the TS validator.

| id | title | size | par | hazard short cut | without blocked | notes |
|----|-------|------|-----|------------------|-----------------|-------|
| cypress-lane-flood | Cypress Lane Flood Response | 10x10 | 16 | 14 | 14 | flooded streets / downed lines on the direct line, stalled car closes the east junction, 2 gates, 7 dead ends |
| storm-damaged-facility | Storm-Damaged Facility Sweep | 10x10 | 21 | 15 | 9 | doorway into the control room jammed (blocked door), live wire beside the lower door, long south-hall detour |
| blocked-evacuation-corridor | Blocked Evacuation Corridor | 8x8 | 13 | 9 | 5 | debris in the straight top corridor, sparking panel on the middle short cut |
| emergency-supply-route | Emergency Supply Route | 8x8 | 12 | 10 | 10 | fallen tree closes the east lane, sinkhole on the middle road, dead-end yard behind the west gate |
| hazardous-research-building | Hazardous Research Building | 10x10 | 21 | 11 | 17 | sealed clean-room door, chemical spills on both fast approaches |

"hazard short cut" = A\* length if hazards were walkable; "without blocked" = shortest
hazard-free length if blocked cells were cleared (both < par, i.e. both are real temptations/detours).
Narrative labels are cosmetic only: no water flow, no spreading hazards, no physics.
Rebuild with `npm run missions` (Python).

## Parity guarantee

`npm test` replays `fixtures/parity_fixtures.json`, recorded with the frozen Python
rescue_sim (training seeds 0-299 + missions + edge cases; never validation/final-test seeds),
and asserts deep equality with `Object.is` semantics for every step result (`reward,
terminated, truncated, info`), the reset info, the final `get_state()` (including the full
trajectory), `replay_episode` output, error messages (after-done and invalid actions), the
canonical `to_dict()`, A\* paths (with and without hazards), 38 invalid-scenario messages,
action parsing, and 851 `round(x, 10)` samples (including exact binary ties).
`npm run parity` additionally regenerates the fixtures and runs the reverse direction:
TS-generated random action sequences (`scripts/gen_ts_runs.mjs`) are re-run in Python by
`scripts/verify_ts_in_python.py` (exact comparison of `replay_episode` output and `get_state()`).

Latest run (see `reports/`): Python->TS 153 cases, 518 sequences, 17,842 steps, 518 final
states, 517 replays, 367 error cases, 1,110 A\* paths; TS->Python 555 runs, 40,846 steps, 0 mismatches.

## Samples

`samples/session_cypress-lane-flood.json` (restart, collision, hazard death, restart,
suboptimal success; full state after every event), `samples/session_score.json`,
`samples/session_astar_comparison.json`, `samples/session_python_check_input.json` and
`samples/session_python_verification.json` (Python `replay_episode` reproduces all 3 attempts exactly).

## Demo (smoke test only - not the WorldShift frontend)

`demo/index.html` + `demo/main.js` (compiled from `demo/main.ts` with `npm run build:demo`):
canvas map, arrows/WASD, R restart, U undo, H A\* overlay after finishing. Serve the
`rescue_play` folder with any static server, e.g. `python -m http.server 8000`, and open
`http://localhost:8000/demo/`.

## Limitations

* Only the step rules / state are ported: no Gymnasium observation arrays, no scenario generator
  (use generated scenario JSON from Python), no FastAPI.
* JSON cannot distinguish `1.0` from `1`: Python rejects float coordinates/sizes such as `1.0`,
  the TS validator accepts them after `JSON.parse` (non-integral values like `1.5` are rejected
  by both with the same message).
* JavaScript `JSON.stringify(-0)` writes `0`; values are equal, only the sign of zero is lost in
  TS-written JSON (Python writes `-0.0`). In memory `pyRound` keeps `-0` like Python.
* `pyRepr` reproduces Python `repr` for JSON values used in error messages; exotic floats (e.g.
  `1e-07`) may print differently.
* `RescueEnvTS` resets in its constructor (Python needs an explicit `reset()`).

## Disclaimer

All missions are fictional. The grid is an abstraction for gameplay and agent evaluation; it is
not representative of real-world flood, storm, structural or chemical behaviour and must not be
used for operational planning or emergency response.
