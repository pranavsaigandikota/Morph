# Rescue Play: Impact Notes (OneEthos: Innovation for Good)

*Knight Hacks IX.*

## Summary

Rescue Play is a small browser grid game about planning a safe route to an exit. Two missions
are framed around Florida-style weather events, both **fictional**:

* **Cypress Lane Flood Response** (10x10, par 16). In-game labels: *flooded streets / downed
  power lines* (hazards), *stalled vehicles* (blocked), *houses and garden walls* (walls),
  *gates and driveways* (doors), *rescue boat launch point* (start), *community shelter* (goal).
  Objective: "Reach the community shelter without entering a flooded street."
* **Storm-Damaged Facility Sweep** (10x10, par 21). Labels: *live wires* (hazards), *fallen
  racking and debris* (blocked), *collapsed / damaged walls* (walls), *intact doorways*
  (doors), *control room* (goal).

Related missions use the same rules: *Emergency Supply Route* (fallen trees / abandoned vehicles,
sinkhole / unstable ground), *Blocked Evacuation Corridor* and *Hazardous Research Building*.
The labels are **narrative only**; the underlying mechanics are the same simple grid rules for
every mission.

## What it can plausibly encourage

Ideas, not measured outcomes:

* **Thinking ahead** about an evacuation route before moving, rather than heading straight
  for the exit.
* Recognising, through the narrative labels, that **floodwater and downed power lines are
  dangerous to cross**. In the game, stepping onto one ends the attempt, even when it looks
  like a shortcut. On Cypress Lane the flooded route is 2 steps shorter than the safe one.
* Seeing that **blocked roads force detours**, and that the safe route can be longer.

## How it could be used (ideas)

* **Classroom or community discussion prompts:** "Why was the shortest route the wrong one?",
  "What would you do if your usual road were blocked?", "Where is your nearest shelter?"
* **Family preparedness conversations:** play a mission together, then talk about your own
  household's plan using official guidance.
* **Comparing choices:** the A\* overlay shows an optimal safe route, which can start a
  conversation about planning, not a judgement of the player.

These uses have **not been tested** with students, families or communities.

## What it does NOT do

* No real flood physics, real maps, real data or forecasts. Nothing in the game models water,
  weather, wind or structural behaviour.
* No environmental impact metrics. We do not measure or claim any environmental effect.
* No validated educational outcomes. We have no user studies, surveys or learning data.
* Not for operational or emergency use. It must not be used to plan a real evacuation.

Each mission ships this disclaimer in its metadata (verbatim): *"Fictional scenario. A discrete
grid abstraction for gameplay and evaluation only; it is not representative of real-world
flood, storm, structural or chemical behaviour and must not be used for operational planning
or emergency response."*

## Real-world preparedness: consult official sources

For real hurricane and flood preparedness, consult official sources such as **Ready.gov**,
**FEMA**, the **National Weather Service / National Hurricane Center**, and your **local
county emergency management** office, and follow instructions from local authorities. This
project does not replace them.

## Ethical design notes

* **Fictional locations and people:** "Cypress Lane" and all other mission settings are invented;
  no real addresses, maps or people are used.
* **Disclaimers:** every mission includes the disclaimer and a note that the mechanics have no
  water flow, no spreading hazards and no physics. The smoke-test demo page shows a disclaimer
  banner. Whether the final WorldShift frontend displays the disclaimer is up to that frontend.
* **No personal data:** the game runs locally in the browser and collects nothing.
* **Accessibility (honest current state):**
  * Keyboard play is supported: arrow keys or WASD (tap = 1 step, hold = repeat at about 5
    steps/s), R restart, U undo, and H shows the A\* route after finishing.
  * The smoke-test demo **relies on colour** to tell cell types apart: walls, debris, hazards
    and doors are coloured squares without text or patterns on the map. Only the start
    ("S") and goal ("G") carry letters. A text colour legend is shown above the map.
  * The player route (red) and the A\* route (green) are distinguished by colour only, which
    is a problem for red-green colour blindness.
  * The canvas has no screen-reader text alternative; the status panel below it is plain text.
  * The demo has an on-screen D-pad (up, down, left, right and Restart buttons with aria-labels,
    one step per click or tap). Movement buttons are disabled after the episode ends. It has
    not been tested on touch devices or with screen readers.
* **Future work:** patterns or icons for every cell type and colour-blind-safe route colours;
  a text or screen-reader description of the map and of each move; touch controls; localisation
  (for example Spanish and Haitian Creole for Florida communities); and partnering with
  educators or emergency-management professionals to review the content and evaluate whether
  it actually helps.
