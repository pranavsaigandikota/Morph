import { readFileSync, existsSync } from "node:fs";
import { describe, expect, it } from "vitest";
import {
  RescueGame, RescueEnvTS, Scenario, ScenarioError, astarPath, compareWithAStar, computeScore, keyToAction,
  pathToActions, pyRound, replayEpisode, defaultMaxSteps,
} from "../src/index.js";

const root = new URL("..", import.meta.url);
const readJson = (p: string) => JSON.parse(readFileSync(new URL(p, root), "utf-8"));
const box = (w: number, h: number) => {
  const out: [number, number][] = [];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (x === 0 || y === 0 || x === w - 1 || y === h - 1) out.push([x, y]);
  return out;
};
const corridor = { seed: null, width: 5, height: 5, start: [1, 1], goal: [3, 3], walls: box(5, 5), hazards: [[2, 1]], max_steps: 20 } as any;

describe("rules", () => {
  it("collision keeps position and consumes the step", () => {
    const env = new RescueEnvTS(corridor);
    const r = env.step(0);
    expect(r.info.collision).toBe(true);
    expect(r.info.position).toEqual([1, 1]);
    expect(r.reward).toBe(-1.1);
    expect(env.stepCount).toBe(1);
  });
  it("hazard terminates by default, continues with hazardTerminates=false", () => {
    const a = new RescueEnvTS(corridor);
    expect(a.step("right")).toMatchObject({ reward: -5.1, terminated: true, info: { outcome: "hazard" } });
    expect(() => a.step(1)).toThrow("episode is over; call reset()");
    const b = new RescueEnvTS(corridor, { hazardTerminates: false });
    expect(b.step(3)).toMatchObject({ terminated: false, info: { hazard: true, outcome: null } });
  });
  it("goal, timeout, default max_steps", () => {
    const env = new RescueEnvTS(corridor);
    for (const a of [1, 1, 3]) env.step(a);
    expect(env.step(3)).toMatchObject({ reward: 9.9, terminated: true, truncated: false, info: { outcome: "success" } });
    const t = new RescueEnvTS({ ...corridor, max_steps: 2 });
    t.step(0);
    expect(t.step(0)).toMatchObject({ truncated: true, terminated: false, info: { outcome: "timeout" } });
    expect(defaultMaxSteps(10, 10)).toBe(150);
    expect(defaultMaxSteps(8, 8)).toBe(96);
    expect(defaultMaxSteps(5, 7)).toBe(52); // 52.5 -> banker's rounding -> 52 (Python round)
  });
  it("pyRound differs from naive toFixed on ties", () => {
    expect(pyRound(0.00048828125, 10)).toBe(0.0004882812);
    expect(Number((0.00048828125).toFixed(10))).toBe(0.0004882813);
    expect(Object.is(pyRound(-1e-11, 10), -0)).toBe(true);
  });
  it("scenario validation errors", () => {
    expect(() => Scenario.fromDict({ ...corridor, goal: [1, 1] })).toThrow(new ScenarioError("start and goal must differ"));
    expect(() => Scenario.fromDict({ ...corridor, start: [9, 9] })).toThrow("start cell [9, 9] is out of bounds for 5x5");
  });
});

describe("keys and A*", () => {
  it("keyToAction", () => {
    expect(["ArrowUp", "w", "W", "KeyW"].map(keyToAction)).toEqual([0, 0, 0, 0]);
    expect(["ArrowDown", "s", "KeyS"].map(keyToAction)).toEqual([1, 1, 1]);
    expect(["ArrowLeft", "a", "KeyA"].map(keyToAction)).toEqual([2, 2, 2]);
    expect(["ArrowRight", "d", "KeyD"].map(keyToAction)).toEqual([3, 3, 3]);
    expect(keyToAction("Enter")).toBeNull();
  });
  it("pathToActions + null path", () => {
    expect(pathToActions([[1, 1], [1, 0], [1, 1], [0, 1], [1, 1]])).toEqual([0, 1, 2, 3]);
    expect(() => pathToActions([[1, 1], [3, 1]])).toThrow("not 4-adjacent");
    const walled = { ...corridor, walls: [...box(5, 5), [2, 2], [3, 2]], hazards: [[2, 3]] };
    expect(astarPath(walled)).toBeNull();
    expect(astarPath(walled, { allowHazards: true })).toEqual([[1, 1], [1, 2], [1, 3], [2, 3], [3, 3]]);
  });
});

describe("RescueGame play layer", () => {
  it("restart, undo, metrics, score, comparison, export", () => {
    const g = new RescueGame(corridor);
    g.step("ArrowUp"); // collision
    g.step("ArrowRight"); // hazard death
    expect(g.metrics()).toMatchObject({ steps: 2, collisions: 1, hazards_entered: 1, outcome: "hazard", failure: true });
    expect(g.score()).toMatchObject({ score: 0, stars: 0, status: "failure", reason: "hazard" });
    expect(g.undo()).toBe(true); // back to after the collision
    expect(g.metrics()).toMatchObject({ steps: 1, outcome: null, undo_used: true, undo_count: 1 });
    expect(g.getState().agent).toEqual([1, 1]);
    g.restart();
    expect(g.metrics()).toMatchObject({ steps: 0, restarts: 1, undo_used: false });
    for (const k of ["s", "d", "s", "d"]) g.step(k);
    expect(g.metrics()).toMatchObject({ success: true, steps: 4 });
    expect(g.score()).toMatchObject({ score: 1000, stars: 3, efficiency: 1 });
    const cmp = g.compareWithAStar();
    expect(cmp.optimal_length).toBe(4);
    expect(cmp.extra_steps).toBe(0);
    expect(cmp.player_route[0]).toEqual([1, 1]);
    const exp = g.exportReplayInput();
    const rep = replayEpisode(exp.actions, exp.scenario, { hazardTerminates: exp.hazard_terminates });
    expect(rep.outcome).toBe("success");
    expect(rep.trajectory).toEqual(g.getState().trajectory);
    // hazard attempt was undone; the restarted unfinished attempt is logged, then the success
    expect(g.attempts.map((a) => [a.outcome, a.ended_by, a.undo_used])).toEqual([[null, "restart", true], ["success", "done", false]]);
  });
  it("computeScore definition", () => {
    expect(computeScore("success", 20, 0, 10)).toMatchObject({ score: 500, stars: 1 });
    expect(computeScore("success", 12, 2, 10)).toMatchObject({ score: 733, stars: 2, collision_penalty: 100 });
    expect(computeScore("success", 100, 30, 10).score).toBe(0);
    expect(computeScore("timeout", 5, 0, 4)).toMatchObject({ score: 0, reason: "timeout" });
    expect(computeScore(null, 3, 0, 4)).toMatchObject({ score: null, status: "in_progress" });
  });
  it("compareWithAStar divergence", () => {
    const traj = new RescueGame(corridor);
    for (const a of [1, 3, 1, 3]) traj.step(a);
    const c = compareWithAStar(traj.getState().trajectory!, corridor);
    expect(c.success).toBe(true);
    const ast = astarPath(corridor)!;
    const expected = [1, 3, 1, 3].findIndex((_, i) => {
      const t = traj.getState().trajectory![i].to;
      return t[0] !== ast[i + 1][0] || t[1] !== ast[i + 1][1];
    });
    expect(c.first_divergence_step).toBe(expected === -1 ? null : expected + 1);
  });
});

describe("missions", () => {
  const index = readJson("missions/index.json");
  const manifest = readJson("data/rescue-play/manifest.json");
  it("has 5 missions, >= two 10x10", () => {
    expect(index.missions.length).toBe(5);
    expect(index.missions.filter((m: any) => m.map_size === "10x10").length).toBeGreaterThanOrEqual(2);
  });
  for (const entry of index.missions) {
    it(`mission ${entry.id} is valid in TS, hazard-free solvable, par == TS A*`, () => {
      const d = readJson(`missions/${entry.file}`);
      const sc = Scenario.fromDict(d).validate(true);
      expect(sc.hasHazardFreePath()).toBe(true);
      const path = astarPath(sc)!;
      expect(path.length - 1).toBe(d.mission.par);
      expect(d.mission.handcrafted).toBe(true);
      expect(d.seed).toBeGreaterThanOrEqual(900001);
      expect(d.mission.disclaimer).toMatch(/Fictional/);
      expect(d.mission.analysis.hazard_shortcut_exists).toBe(true);
      expect(d.mission.analysis.blocked_forces_detour).toBe(true);
      const risky = astarPath(sc, { allowHazards: true })!;
      expect(risky.length).toBeLessThan(path.length);
      const route = readJson(`data/rescue-play/routes/${entry.id}_astar.json`);
      expect(route.path).toEqual(path);
      expect(route.actions).toEqual(pathToActions(path));
      expect(readJson(`data/rescue-play/missions/${entry.file}`)).toEqual(d);
    });
  }
  it("frontend manifest paths are relative and resolve", () => {
    for (const m of manifest.missions) {
      for (const p of [m.mission, m.astar_route]) {
        expect(p).not.toMatch(/^\/|\\|^[A-Za-z]:|\.\./);
        expect(existsSync(new URL(`data/rescue-play/${p}`, root))).toBe(true);
      }
    }
  });
});
