import { describe, expect, it, vi } from "vitest";
import { RescueGame, createStepController, keyToAction, type KeyEventLike } from "../src/index.js";

const box = (w: number, h: number) => {
  const out: [number, number][] = [];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (x === 0 || y === 0 || x === w - 1 || y === h - 1) out.push([x, y]);
  return out;
};
// start [1,1], hazard [2,1] (right), goal [3,3]; up/left from start are walls
const corridor = { seed: null, width: 5, height: 5, start: [1, 1], goal: [3, 3], walls: box(5, 5), hazards: [[2, 1]], max_steps: 20 } as any;

function kd(key: string, extra: Partial<KeyEventLike> = {}) {
  const ev = { key, repeat: false, preventDefault: vi.fn(), ...extra };
  return ev;
}
function setup(scenario = corridor, opts = {}) {
  const game = new RescueGame(scenario);
  const onChange = vi.fn();
  const ctl = createStepController(game, { onChange, ...opts });
  return { game, ctl, onChange };
}

describe("createStepController (CONTROL_CONTRACT)", () => {
  it("rule 2: a repeat event is ignored", () => {
    const { game, ctl } = setup();
    const ev = kd("ArrowDown", { repeat: true });
    expect(ctl.handleKeyDown(ev).type).toBe("ignored_repeat");
    expect(game.env.stepCount).toBe(0);
    expect(ev.preventDefault).toHaveBeenCalled();
  });

  it("rule 1: a second keydown without keyup is ignored", () => {
    const { game, ctl } = setup();
    expect(ctl.handleKeyDown(kd("ArrowDown")).type).toBe("step");
    expect(ctl.handleKeyDown(kd("ArrowDown")).type).toBe("ignored_held");
    expect(game.env.stepCount).toBe(1);
  });

  it("rule 3: keyup re-arms the key", () => {
    const { game, ctl } = setup();
    ctl.handleKeyDown(kd("s"));
    ctl.handleKeyUp(kd("s"));
    expect(ctl.handleKeyDown(kd("s")).type).toBe("step");
    expect(game.env.stepCount).toBe(2);
    expect(game.getState().agent).toEqual([1, 3]);
  });

  it("blur re-arms held keys", () => {
    const { game, ctl } = setup();
    ctl.handleKeyDown(kd("ArrowDown"));
    expect(ctl.heldKeys.size).toBe(1);
    ctl.handleBlur();
    expect(ctl.heldKeys.size).toBe(0);
    expect(ctl.handleKeyDown(kd("ArrowDown")).type).toBe("step");
    expect(game.env.stepCount).toBe(2);
  });

  it("rule 4: D-pad press steps exactly once per call", () => {
    const { game, ctl, onChange } = setup();
    expect(ctl.press(1).type).toBe("step");
    expect(game.env.stepCount).toBe(1);
    expect(ctl.press("down").type).toBe("step");
    expect(game.env.stepCount).toBe(2);
    expect(onChange).toHaveBeenCalledTimes(2);
    expect(onChange.mock.calls[1][1]).toMatchObject({ type: "step", source: "dpad", action: 1 });
    expect(onChange.mock.calls[1][0].step_count).toBe(2);
  });

  it("rule 5: preventDefault for arrows/WASD/R only while active, not for unrelated keys", () => {
    let activeFlag = true;
    const { ctl } = setup(corridor, { isActive: () => activeFlag });
    for (const k of ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "w", "a", "s", "d", "r"]) {
      const ev = kd(k);
      ctl.handleKeyDown(ev);
      ctl.handleKeyUp(ev);
      expect(ev.preventDefault, k).toHaveBeenCalledTimes(1);
    }
    for (const k of ["Tab", "Enter", "x", "F5", " "]) {
      const ev = kd(k);
      expect(ctl.handleKeyDown(ev).type).toBe("ignored_key");
      expect(ev.preventDefault, k).not.toHaveBeenCalled();
    }
    activeFlag = false;
    const ev = kd("ArrowDown");
    expect(ctl.handleKeyDown(ev).type).toBe("ignored_inactive");
    expect(ev.preventDefault).not.toHaveBeenCalled();
  });

  it("rule 8: no movement after success", () => {
    const { game, ctl } = setup();
    for (const a of [1, 1, 3, 3] as const) ctl.press(a);
    expect(game.getState().outcome).toBe("success");
    expect(ctl.canMove).toBe(false);
    expect(ctl.press(0).type).toBe("ignored_done");
    ctl.handleKeyUp(kd("ArrowUp"));
    expect(ctl.handleKeyDown(kd("ArrowUp")).type).toBe("ignored_done");
    expect(ctl.handleKeyDown(kd("u")).type).toBe("ignored_done"); // undo cannot revive a finished episode
    expect(game.env.stepCount).toBe(4);
    expect(ctl.handleKeyDown(kd("h"))).toMatchObject({ type: "toggle_astar", showAStar: true });
  });

  it("rule 8: no movement after hazard failure", () => {
    const { game, ctl } = setup();
    ctl.press(3);
    expect(game.getState().outcome).toBe("hazard");
    expect(ctl.press(1).type).toBe("ignored_done");
    expect(ctl.handleKeyDown(kd("ArrowDown")).type).toBe("ignored_done");
    expect(game.env.stepCount).toBe(1);
  });

  it("rule 8: no movement after timeout", () => {
    const { game, ctl } = setup({ ...corridor, max_steps: 2 });
    ctl.press(0);
    ctl.press(0);
    expect(game.getState().outcome).toBe("timeout");
    expect(ctl.press(1).type).toBe("ignored_done");
    expect(game.env.stepCount).toBe(2);
  });

  it("rules 6/8: restart re-enables movement and clears state", () => {
    const { game, ctl, onChange } = setup();
    ctl.handleKeyDown(kd("ArrowDown")); // held, not released
    ctl.press(0);
    ctl.press(1);
    ctl.press(3);
    ctl.press(3); // route: [1,2] up [1,1] down [1,2] right [2,2] right [3,2]
    ctl.press(1); // goal [3,3]
    expect(game.done).toBe(true);
    ctl.toggleAStar();
    expect(ctl.showAStar).toBe(true);
    const ev = ctl.handleKeyDown(kd("R"));
    expect(ev.type).toBe("restart");
    expect(ctl.showAStar).toBe(false);
    expect(ctl.lastCollision).toBe(false);
    expect(ctl.heldKeys.size).toBe(0);
    expect(ctl.canMove).toBe(true);
    expect(game.getState()).toMatchObject({ step_count: 0, agent: [1, 1], done: false, trajectory: [] });
    expect(game.restarts).toBe(1);
    expect(ctl.handleKeyDown(kd("ArrowDown")).type).toBe("step"); // re-armed after restart
    expect(onChange.mock.calls.some((c) => c[1].type === "restart")).toBe(true);
  });

  it("rule 7: collision flag reporting", () => {
    const { ctl } = setup();
    const a = ctl.press(0); // wall above start
    expect(a.collision).toBe(true);
    expect(ctl.lastCollision).toBe(true);
    const b = ctl.press(1);
    expect(b.collision).toBe(false);
    expect(ctl.lastCollision).toBe(false);
    ctl.press(2); // wall left of [1,2]
    expect(ctl.lastCollision).toBe(true);
    ctl.restart();
    expect(ctl.lastCollision).toBe(false);
  });

  it("action mapping is identical to keyToAction", () => {
    const keys = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "w", "W", "a", "A", "s", "S", "d", "D",
      "KeyW", "KeyA", "KeyS", "KeyD"];
    for (const k of keys) {
      const { game, ctl } = setup();
      const ev = ctl.handleKeyDown(kd(k));
      expect(ev.action, k).toBe(keyToAction(k));
      expect(game.env.trajectory[0].action, k).toBe(keyToAction(k));
    }
    const { ctl } = setup();
    expect(ctl.handleKeyDown({ key: "x", code: "KeyW" }).action).toBe(keyToAction("KeyW"));
  });

  it("dispose stops all handling", () => {
    const { game, ctl } = setup();
    ctl.dispose();
    expect(ctl.handleKeyDown(kd("ArrowDown")).type).toBe("ignored_inactive");
    expect(ctl.press(1).type).toBe("ignored_inactive");
    expect(game.env.stepCount).toBe(0);
  });
});
