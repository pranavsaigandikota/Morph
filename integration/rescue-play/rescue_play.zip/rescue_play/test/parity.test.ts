/**
 * Python -> TS parity: replays every fixture recorded with the frozen Python rescue_sim and
 * asserts exact (Object.is-level) equality of every step, final state, outcome and total.
 */
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { describe, expect, it } from "vitest";
import {
  RescueEnvTS, Scenario, ScenarioError, astarPath, parseAction, pyRound, replayEpisode,
} from "../src/index.js";

const root = new URL("..", import.meta.url);
const fx = JSON.parse(readFileSync(new URL("fixtures/parity_fixtures.json", root), "utf-8"));
const counts = { cases: 0, sequences: 0, steps: 0, final_states: 0, replays: 0, errors: 0, astar_paths: 0,
  invalid_scenarios: 0, action_parsing: 0, rounding: 0 };

function runTs(c: any, s: any) {
  const env = new RescueEnvTS(c.scenario, {
    hazardTerminates: c.hazard_terminates, rewardConfig: c.reward_config ?? undefined,
    maxSteps: c.max_steps_override,
  });
  const resetInfo = env.reset();
  const steps: any[] = [];
  let error: any = null;
  for (let i = 0; i < s.actions.length; i++) {
    try {
      steps.push(env.step(s.actions[i]));
    } catch (e: any) {
      error = { index: i, message: e.message, name: e.name };
      break;
    }
  }
  return { env, resetInfo, steps, error };
}

describe("python -> ts parity (fixtures)", () => {
  it("fixture metadata", () => {
    expect(fx.fixture_format_version).toBe(1);
    expect(fx.cases.length).toBeGreaterThan(100);
  });

  for (const c of fx.cases) {
    it(`case ${c.id}`, () => {
      counts.cases++;
      const sc = Scenario.fromDict(c.scenario);
      expect(sc.toDict()).toEqual(c.scenario_canonical);
      expect(astarPath(sc)).toEqual(c.astar);
      expect(astarPath(sc, { allowHazards: true })).toEqual(c.astar_allow_hazards);
      counts.astar_paths += 2;
      for (const s of c.sequences) {
        counts.sequences++;
        const { env, resetInfo, steps, error } = runTs(c, s);
        expect(resetInfo).toEqual(s.reset_info);
        expect(steps.length).toBe(s.steps.length);
        for (let i = 0; i < steps.length; i++) {
          expect(steps[i], `${c.id}/${s.name} step ${i + 1}`).toEqual(s.steps[i]);
          counts.steps++;
        }
        if (s.error) {
          expect(error).not.toBeNull();
          expect(error.index).toBe(s.error.index);
          expect(error.message).toBe(s.error.message);
          expect(error.name).toBe(s.error.type === "RuntimeError" ? "Error" : "ActionError");
          counts.errors++;
        } else {
          expect(error).toBeNull();
        }
        expect(env.getState()).toEqual(s.final_state);
        counts.final_states++;
        if (s.replay) {
          if (s.replay.error) {
            expect(() => replayEpisode(s.actions, c.scenario, { hazardTerminates: c.hazard_terminates,
              rewardConfig: c.reward_config ?? undefined })).toThrow(s.replay.error.message);
          } else {
            expect(replayEpisode(s.actions, c.scenario, { hazardTerminates: c.hazard_terminates,
              rewardConfig: c.reward_config ?? undefined })).toEqual(s.replay);
          }
          counts.replays++;
        }
      }
    });
  }

  it("A* paths for 400+ extra generated scenarios", () => {
    for (const a of fx.astar_only) {
      expect(astarPath(a.scenario), a.id).toEqual(a.astar);
      expect(astarPath(a.scenario, { allowHazards: true }), a.id).toEqual(a.astar_allow_hazards);
      counts.astar_paths += 2;
    }
  });

  it("validation errors match Python exactly", () => {
    for (const v of fx.invalid_scenarios) {
      counts.invalid_scenarios++;
      if (v.valid) {
        expect(() => Scenario.fromDict(v.data)).not.toThrow();
        continue;
      }
      let msg: string | null = null;
      try {
        Scenario.fromDict(v.data);
      } catch (e: any) {
        expect(e).toBeInstanceOf(ScenarioError);
        msg = e.message;
      }
      expect(msg, v.id).toBe(v.error.message);
    }
  });

  it("action parsing matches Python", () => {
    for (const a of fx.action_parsing) {
      counts.action_parsing++;
      if (a.error === null) expect(parseAction(a.input)).toBe(a.action);
      else expect(() => parseAction(a.input)).toThrow(a.error);
    }
  });

  it("pyRound == Python round(x, 10) bit-for-bit", () => {
    for (const r of fx.rounding) {
      counts.rounding++;
      expect(Object.is(pyRound(r.x, 10), r.rounded), `round(${r.x})`).toBe(true);
    }
  });

  it("write summary", () => {
    mkdirSync(new URL("reports/", root), { recursive: true });
    writeFileSync(new URL("reports/parity_ts_summary.json", root),
      JSON.stringify({ direction: "python->ts", fixture_counts: fx.counts, compared: counts }, null, 2) + "\n");
    expect(counts.steps).toBe(fx.counts.steps);
  });
});
