import { describe, expect, it, vi } from "vitest";
import { RescueGame, createStepController, type KeyEventLike, type Scheduler, type StepControllerOptions } from "../src/index.js";

/** Deterministic injectable scheduler: virtual clock, timers fire in time order on advance(). */
function fakeScheduler() {
  let now = 0;
  let seq = 0;
  const timers = new Map<number, { at: number; fn: () => void }>();
  const s: Scheduler & { advance(ms: number): void; pending(): number } = {
    setTimeout(fn, ms) {
      const id = ++seq;
      timers.set(id, { at: now + ms, fn });
      return id;
    },
    clearTimeout(h) {
      timers.delete(h as number);
    },
    advance(ms) {
      const end = now + ms;
      for (;;) {
        let next: [number, { at: number; fn: () => void }] | null = null;
        for (const e of timers) if (e[1].at <= end && (!next || e[1].at < next[1].at || (e[1].at === next[1].at && e[0] < next[0]))) next = e;
        if (!next) break;
        timers.delete(next[0]);
        now = next[1].at;
        next[1].fn();
      }
      now = end;
    },
    pending: () => timers.size,
  };
  return s;
}

// 10x5 open field, start [0,2]; goal far away at [9,4]
const open = { seed: null, width: 10, height: 5, start: [0, 2], goal: [9, 4], walls: [], hazards: [], max_steps: 50 } as any;
const kd = (key: string, extra: Partial<KeyEventLike> = {}) => ({ key, repeat: false, preventDefault: vi.fn(), ...extra });
const ku = (key: string) => ({ key });

function setup(scenario: any = open, opts: StepControllerOptions = {}) {
  const sched = fakeScheduler();
  const game = new RescueGame(scenario);
  const onChange = vi.fn();
  const ctl = createStepController(game, { scheduler: sched, onChange, ...opts });
  return { game, ctl, sched, onChange, steps: () => game.env.stepCount, collisions: () => game.env.collisions };
}
const movingHoldMoves = (onChange: ReturnType<typeof vi.fn>) =>
  onChange.mock.calls.filter((c) => c[1].type === "hold_step" || c[1].type === "hold_stopped_collision");

describe("createStepController hold-to-repeat (CONTROL_CONTRACT t17u)", () => {
  it("rule 1: tap = 1 step, stepped immediately on keydown", () => {
    const { ctl, sched, steps, game } = setup();
    expect(ctl.handleKeyDown(kd("d")).type).toBe("step");
    expect(steps()).toBe(1);
    ctl.handleKeyUp(ku("d"));
    sched.advance(2000);
    expect(steps()).toBe(1);
    expect(game.getState().agent).toEqual([1, 2]);
    expect(ctl.holding).toBe(false);
  });

  it("rule 2: holding 1000 ms gives 1 + 5 steps (nothing early at 199 ms)", () => {
    const { ctl, sched, steps, onChange } = setup();
    ctl.handleKeyDown(kd("ArrowRight"));
    expect(ctl.holding).toBe(true);
    sched.advance(199);
    expect(steps()).toBe(1);
    sched.advance(1);
    expect(steps()).toBe(2);
    sched.advance(800);
    expect(steps()).toBe(6);
    const holds = movingHoldMoves(onChange);
    expect(holds).toHaveLength(5);
    expect(holds.every((c) => c[1].type === "hold_step" && c[1].source === "hold" && c[1].action === 3)).toBe(true);
  });

  it("rule 2: OS repeat events add nothing during a hold (but are preventDefault'd)", () => {
    const { ctl, sched, steps } = setup();
    ctl.handleKeyDown(kd("ArrowRight"));
    for (let t = 0; t < 10; t++) {
      sched.advance(30);
      const ev = kd("ArrowRight", { repeat: true });
      expect(ctl.handleKeyDown(ev).type).toBe("ignored_repeat");
      expect(ev.preventDefault).toHaveBeenCalled();
    }
    sched.advance(100); // t = 400
    expect(steps()).toBe(3);
  });

  it("rule 3: release stops immediately (no step after keyup even when timers advance)", () => {
    const { ctl, sched, steps } = setup();
    ctl.handleKeyDown(kd("ArrowRight"));
    sched.advance(450);
    expect(steps()).toBe(3);
    ctl.handleKeyUp(ku("ArrowRight"));
    expect(ctl.holding).toBe(false);
    expect(sched.pending()).toBe(0);
    sched.advance(5000);
    expect(steps()).toBe(3);
  });

  it("rule 4: holding into a wall gives exactly 1 collision then halts; a re-press gives one more", () => {
    const { ctl, sched, steps, collisions, game } = setup({ ...open, walls: [[1, 2]] });
    const ev = ctl.handleKeyDown(kd("d"));
    expect(ev).toMatchObject({ type: "step", collision: true });
    expect(ctl.holding).toBe(false);
    sched.advance(2000);
    expect(steps()).toBe(1);
    expect(collisions()).toBe(1);
    expect(game.metrics().native_total_reward).toBe(-1.1);
    ctl.handleKeyUp(ku("d"));
    ctl.handleKeyDown(kd("d"));
    sched.advance(2000);
    expect(steps()).toBe(2);
    expect(collisions()).toBe(2);
  });

  it("rule 4: a collision mid-hold halts the hold", () => {
    const { ctl, sched, steps, collisions, onChange, game } = setup({ ...open, walls: [[3, 2]] });
    ctl.handleKeyDown(kd("d")); // -> [1,2]
    sched.advance(400); // 200: [2,2]; 400: blocked by [3,2]
    expect(steps()).toBe(3);
    expect(collisions()).toBe(1);
    const last = onChange.mock.calls.at(-1)![1];
    expect(last).toMatchObject({ type: "hold_stopped_collision", source: "hold", collision: true });
    expect(ctl.holding).toBe(false);
    expect(ctl.collisionFlash).toBe(true);
    sched.advance(3000);
    expect(steps()).toBe(3);
    expect(game.getState().agent).toEqual([2, 2]);
  });

  it("rule 5: the hold stops on success", () => {
    const { ctl, sched, steps, game } = setup({ ...open, goal: [3, 2] });
    ctl.handleKeyDown(kd("d"));
    sched.advance(400);
    expect(game.getState().outcome).toBe("success");
    expect(ctl.holding).toBe(false);
    expect(sched.pending()).toBe(0);
    sched.advance(2000);
    expect(steps()).toBe(3);
  });

  it("rule 5: the hold stops on a hazard", () => {
    const { ctl, sched, steps, game } = setup({ ...open, hazards: [[2, 2]] });
    ctl.handleKeyDown(kd("d"));
    sched.advance(1000);
    expect(game.getState().outcome).toBe("hazard");
    expect(steps()).toBe(2);
    expect(ctl.holding).toBe(false);
  });

  it("rule 5: the hold stops at timeout", () => {
    const { ctl, sched, steps, game } = setup({ ...open, max_steps: 3 });
    ctl.handleKeyDown(kd("d"));
    sched.advance(2000);
    expect(game.getState().outcome).toBe("timeout");
    expect(steps()).toBe(3);
    expect(sched.pending()).toBe(0);
  });

  it("rules 5/7: after done, undo is refused and no steps happen", () => {
    const { ctl, sched, steps, game } = setup({ ...open, goal: [1, 2] });
    ctl.handleKeyDown(kd("d"));
    expect(game.done).toBe(true);
    expect(ctl.undo().type).toBe("ignored_done");
    expect(ctl.handleKeyDown(kd("u")).type).toBe("ignored_done");
    ctl.handleKeyUp(ku("d"));
    expect(ctl.handleKeyDown(kd("d")).type).toBe("ignored_done");
    expect(ctl.press(1).type).toBe("ignored_done");
    sched.advance(2000);
    expect(steps()).toBe(1);
    expect(game.undoCount).toBe(0);
  });

  it("rule 7: undo during play works and cancels the hold", () => {
    const { ctl, sched, steps, game } = setup();
    ctl.handleKeyDown(kd("d"));
    sched.advance(200);
    expect(steps()).toBe(2);
    expect(ctl.handleKeyDown(kd("u")).type).toBe("undo");
    expect(steps()).toBe(1);
    expect(ctl.holding).toBe(false);
    sched.advance(2000);
    expect(steps()).toBe(1); // key still physically held, but the hold is cancelled
    expect(game.getState().agent).toEqual([1, 2]);
    ctl.handleKeyUp(ku("d"));
    ctl.handleKeyDown(kd("d"));
    expect(steps()).toBe(2);
  });

  it("rule 8: restart clears the timers and resets step, score and trajectory", () => {
    const { ctl, sched, steps, game } = setup({ ...open, walls: [[3, 2]] });
    ctl.handleKeyDown(kd("d"));
    sched.advance(400); // ends with a collision -> flash timer pending
    ctl.handleKeyDown(kd("s")); // new hold pending
    expect(sched.pending()).toBeGreaterThan(0);
    const fresh = new RescueGame({ ...open, walls: [[3, 2]] });
    expect(ctl.restart().type).toBe("restart");
    expect(sched.pending()).toBe(0);
    expect(ctl.holding).toBe(false);
    expect(ctl.collisionFlash).toBe(false);
    expect(ctl.lastCollision).toBe(false);
    expect(ctl.heldKeys.size).toBe(0);
    expect(ctl.showAStar).toBe(false);
    expect(steps()).toBe(0);
    expect(game.getState().trajectory).toEqual([]);
    expect(game.score()).toEqual(fresh.score());
    expect(game.metrics()).toMatchObject({ steps: 0, collisions: 0, restarts: 1 });
    sched.advance(2000);
    expect(steps()).toBe(0);
  });

  it("rule 3: blur stops the hold (and visibility-hidden does too)", () => {
    const { ctl, sched, steps } = setup();
    ctl.handleKeyDown(kd("d"));
    sched.advance(200);
    ctl.handleBlur();
    expect(ctl.holding).toBe(false);
    sched.advance(2000);
    expect(steps()).toBe(2);
    ctl.handleKeyDown(kd("d")); // re-armed
    sched.advance(200);
    ctl.handleVisibilityHidden();
    sched.advance(2000);
    expect(steps()).toBe(4);
  });

  it("holdRepeatMs = 0 gives one step per press", () => {
    const { ctl, sched, steps } = setup(open, { holdRepeatMs: 0 });
    ctl.handleKeyDown(kd("d"));
    expect(ctl.holding).toBe(false);
    sched.advance(5000);
    expect(steps()).toBe(1);
    expect(ctl.handleKeyDown(kd("d")).type).toBe("ignored_held");
    ctl.handleKeyUp(ku("d"));
    ctl.handleKeyDown(kd("d"));
    expect(steps()).toBe(2);
  });

  it("rule 6: the D-pad stays one step per click (no hold)", () => {
    const { ctl, sched, steps } = setup();
    expect(ctl.press(3).type).toBe("step");
    expect(ctl.holding).toBe(false);
    sched.advance(5000);
    expect(steps()).toBe(1);
    ctl.press("right");
    expect(steps()).toBe(2);
  });

  it("rule 3: the most recently pressed key drives; releasing it stops with no fallback", () => {
    const { ctl, sched, steps, game } = setup();
    ctl.handleKeyDown(kd("ArrowRight")); // [1,2]
    sched.advance(200); // [2,2]
    ctl.handleKeyDown(kd("ArrowDown")); // immediate: [2,3]
    expect(game.getState().agent).toEqual([2, 3]);
    sched.advance(200); // down again: [2,4] (right no longer repeats)
    expect(game.getState().agent).toEqual([2, 4]);
    ctl.handleKeyUp(ku("ArrowDown")); // right still held, but no fallback
    sched.advance(2000);
    expect(steps()).toBe(4);
    expect(game.getState().agent).toEqual([2, 4]);
    ctl.handleKeyUp(ku("ArrowRight")); // releasing the non-driver key is harmless
    expect(steps()).toBe(4);
  });

  it("dispose clears the timers", () => {
    const { ctl, sched, steps } = setup({ ...open, walls: [[2, 2]] });
    ctl.handleKeyDown(kd("d"));
    sched.advance(200); // collision -> flash timer
    ctl.handleKeyDown(kd("s")); // hold timer
    expect(sched.pending()).toBeGreaterThan(0);
    ctl.dispose();
    expect(sched.pending()).toBe(0);
    sched.advance(5000);
    expect(steps()).toBe(3);
    expect(ctl.handleKeyDown(kd("w")).type).toBe("ignored_inactive");
  });

  it("collision flash ends after collisionFlashMs (default 350) with a flash_end event", () => {
    const { ctl, sched, onChange } = setup({ ...open, walls: [[1, 2]] });
    ctl.press(3);
    expect(ctl.collisionFlash).toBe(true);
    sched.advance(349);
    expect(ctl.collisionFlash).toBe(true);
    sched.advance(1);
    expect(ctl.collisionFlash).toBe(false);
    expect(onChange.mock.calls.at(-1)![1].type).toBe("flash_end");
    expect(ctl.lastCollision).toBe(true); // last step still was a collision
  });

  it("works with vitest fake timers and the default (global) scheduler", () => {
    vi.useFakeTimers();
    try {
      const game = new RescueGame(open);
      const ctl = createStepController(game);
      ctl.handleKeyDown(kd("d"));
      vi.advanceTimersByTime(1000);
      expect(game.env.stepCount).toBe(6);
      ctl.handleKeyUp(ku("d"));
      vi.advanceTimersByTime(1000);
      expect(game.env.stepCount).toBe(6);
      ctl.dispose();
    } finally {
      vi.useRealTimers();
    }
  });
});
