"""Re-run TS-produced action sequences in the FROZEN Python rescue_sim and compare exactly.

    python scripts/verify_ts_in_python.py [INPUT_JSON] [--out REPORT_JSON]

INPUT_JSON (default fixtures/ts_runs.json): {"runs": [{"id", "scenario", "hazard_terminates",
"reward_config", "actions", "ts_replay", "ts_state"}]} as written by scripts/gen_ts_runs.mjs or
scripts/make_sample_session.mjs. For each run, replay_episode(actions, scenario, ...) must equal ts_replay
and a stepped RescueEnv.get_state() must equal ts_state. Floats are compared with exact equality.
Exit code 1 on any mismatch.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

from rescue_sim import RescueEnv, replay_episode

ROOT = Path(__file__).resolve().parents[1]


def diff(a, b, path="$", out=None, stats=None):
    """Exact structural comparison; numbers compare with == (exact for floats)."""
    out = [] if out is None else out
    if isinstance(a, bool) or isinstance(b, bool):
        if a is not b:
            out.append(f"{path}: {a!r} != {b!r}")
    elif isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if a != b:
            out.append(f"{path}: {a!r} != {b!r}")
        elif stats is not None and isinstance(a, float) and a == 0 and math.copysign(1, a) < 0:
            stats["negative_zero"] += 1  # JSON from JS cannot carry -0; value equal
    elif isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b):
            out.append(f"{path}: keys {sorted(set(a) ^ set(b))}")
        for k in a.keys() & b.keys():
            diff(a[k], b[k], f"{path}.{k}", out, stats)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append(f"{path}: len {len(a)} != {len(b)}")
        for i, (x, y) in enumerate(zip(a, b)):
            diff(x, y, f"{path}[{i}]", out, stats)
    elif a != b:
        out.append(f"{path}: {a!r} != {b!r}")
    return out


def python_state(run):
    env = RescueEnv(scenario=run["scenario"], reward_config=run.get("reward_config"),
                    hazard_terminates=run.get("hazard_terminates", True))
    env.reset()
    for a in run["actions"]:
        if env.done:
            break
        env.step(a)
    return env.get_state()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", nargs="?", default=str(ROOT / "fixtures" / "ts_runs.json"))
    ap.add_argument("--out", default=str(ROOT / "reports" / "ts_in_python_results.json"))
    args = ap.parse_args()
    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    stats = {"negative_zero": 0}
    results, steps, bad = [], 0, 0
    for run in data["runs"]:
        py_rep = replay_episode(run["actions"], run["scenario"], reward_config=run.get("reward_config"),
                                hazard_terminates=run.get("hazard_terminates", True))
        problems = diff(py_rep, run["ts_replay"], "$.replay", stats=stats)
        if "ts_state" in run:
            problems += diff(python_state(run), run["ts_state"], "$.state", stats=stats)
        steps += len(py_rep["trajectory"])
        bad += bool(problems)
        results.append({"id": run["id"], "ok": not problems, "steps": len(py_rep["trajectory"]),
                        "outcome": py_rep["outcome"], "total_reward": py_rep["total_reward"],
                        "problems": problems[:10]})
    report = {"direction": "ts->python", "input": Path(args.input).name, "runs": len(results),
              "steps_compared": steps, "mismatching_runs": bad, "ok": bad == 0,
              "negative_zero_values_seen": stats["negative_zero"],
              "comparison": "exact equality of replay_episode output and get_state() (floats with ==)",
              "results": results if len(results) <= 20 else [r for r in results if not r["ok"]]}
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(f"ts->python: {len(results)} runs, {steps} steps, mismatching runs: {bad} -> {out.name}")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
