// Run a Python script with an interpreter that can import rescue_sim (portable; no shell).
// Interpreter: $RESCUE_SIM_PYTHON, else ../rescue_sim/.venv (Windows or POSIX layout), else python3/python/py.
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");

export function findPython() {
  if (process.env.RESCUE_SIM_PYTHON) return [process.env.RESCUE_SIM_PYTHON];
  const sib = resolve(ROOT, "..", "rescue_sim", ".venv");
  for (const p of [join(sib, "Scripts", "python.exe"), join(sib, "bin", "python")]) if (existsSync(p)) return [p];
  for (const cand of [["python3"], ["python"], ["py", "-3"]]) {
    const r = spawnSync(cand[0], [...cand.slice(1), "-c", "import rescue_sim"], { stdio: "ignore" });
    if (r.status === 0) return cand;
  }
  throw new Error("No Python with rescue_sim found. Set RESCUE_SIM_PYTHON to the rescue_sim venv python.");
}

export function runPython(script, args = []) {
  const py = findPython();
  const r = spawnSync(py[0], [...py.slice(1), join(ROOT, script), ...args], {
    cwd: ROOT, stdio: "inherit", env: { ...process.env, PYTHONDONTWRITEBYTECODE: "1", PYTHONUTF8: "1" },
  });
  return r.status ?? 1;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [script, ...rest] = process.argv.slice(2);
  process.exit(runPython(script, rest));
}
