"""Build the hand-designed missions (missions/*.json, missions/index.json) and the
frontend export (data/rescue-play/...). Uses the frozen rescue_sim read-only.

    python scripts/make_missions.py [--check]

Map legend: '#' wall, 'X' blocked, '^' hazard, 'D' door (gap in a wall),
'B' blocked door (door + blocked), 'S' start, 'G' goal, '.' floor.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import deque
from pathlib import Path

from rescue_sim import Scenario, astar_path, path_to_actions
from rescue_sim.env import COORDINATE_SYSTEM
from rescue_sim.pathfinding import ACTION_NAMES, ACTIONS

ROOT = Path(__file__).resolve().parents[1]
DISCLAIMER = ("Fictional scenario. A discrete grid abstraction for gameplay and evaluation only; it is not "
              "representative of real-world flood, storm, structural or chemical behaviour and must not be used "
              "for operational planning or emergency response.")
CONTROLS = {"up": ["ArrowUp", "W"], "down": ["ArrowDown", "S"], "left": ["ArrowLeft", "A"],
            "right": ["ArrowRight", "D"], "restart": ["R"], "undo": ["U / Backspace (play feature)"],
            "show_astar_after_finish": ["H"]}

MISSIONS = [
    {
        "id": "cypress-lane-flood",
        "seed": 900001,
        "title": "Cypress Lane Flood Response",
        "difficulty": "easy",
        "briefing": ("Heavy rain has flooded parts of the fictional Cypress Lane neighbourhood. A resident is "
                     "waiting at the community shelter on the far side of the block. Several streets are "
                     "under water and a stalled car blocks the main alley."),
        "objective": "Reach the community shelter without entering a flooded street.",
        "legend": {"walls": "houses and garden walls", "blocked": "stalled vehicles", "doors": "gates and driveways",
                   "hazards": "flooded streets / downed power lines", "start": "rescue boat launch point",
                   "goal": "community shelter"},
        "map": [
            "##########",
            "#S...#...#",
            "#.##.D.#.#",
            "#.#^.#.#.#",
            "#.#..X.#.#",
            "#.##^#X..#",
            "#....D^#.#",
            "###.##.#.#",
            "#....^..G#",
            "##########",
        ],
        "shortcut_note": "The quickest-looking line south through the middle gardens crosses flooded streets, and a stalled car at the east junction closes the short way to the east street, so the safe route loops along the north road and down the far east street.",
    },
    {
        "id": "storm-damaged-facility",
        "seed": 900002,
        "title": "Storm-Damaged Facility Sweep",
        "difficulty": "medium",
        "briefing": ("A storm has damaged a fictional logistics facility. Interior walls have partly collapsed "
                     "and live wires hang near the loading bay. A worker is sheltering in the control room."),
        "objective": "Reach the control room through the intact doors, avoiding live wires.",
        "legend": {"walls": "collapsed / damaged walls", "blocked": "fallen racking and debris",
                   "doors": "intact doorways", "hazards": "live wires", "start": "east entrance",
                   "goal": "control room"},
        "map": [
            "##########",
            "#G..#...S#",
            "#...B.^..#",
            "#...#.##.#",
            "##D##.#..#",
            "#..^..#.X#",
            "#.###.#..#",
            "#.....^..#",
            "#^###.##.#",
            "##########",
        ],
        "shortcut_note": "The doorway straight into the control room (west wall) is jammed with debris. The quickest detour cuts across a live wire next to the lower door; the safe route swings through the south hall.",
    },
    {
        "id": "blocked-evacuation-corridor",
        "seed": 900003,
        "title": "Blocked Evacuation Corridor",
        "difficulty": "medium",
        "briefing": ("The main evacuation corridor of a fictional office block is blocked by debris. Staff must "
                     "be guided to the emergency exit via side rooms while avoiding a sparking panel."),
        "objective": "Reach the emergency exit using the side rooms.",
        "legend": {"walls": "office walls", "blocked": "debris piles", "doors": "office doors",
                   "hazards": "sparking electrical panel", "start": "stairwell", "goal": "emergency exit"},
        "map": [
            "########",
            "#S..X.G#",
            "#.#.#..#",
            "#.#.^..#",
            "#.D.##.#",
            "#.#....#",
            "#...#..#",
            "########",
        ],
        "shortcut_note": "The straight top corridor is blocked by debris. The tempting short cut through the middle room steps onto a sparking panel; the safe route goes down the side room and back up the east wall.",
    },
    {
        "id": "emergency-supply-route",
        "seed": 900004,
        "title": "Emergency Supply Route",
        "difficulty": "easy",
        "briefing": ("A fictional field hospital needs medical supplies. The road network between the depot and "
                     "the hospital tent has a fallen tree and an unstable sinkhole."),
        "objective": "Deliver the supplies to the hospital tent.",
        "legend": {"walls": "buildings and fences", "blocked": "fallen trees / abandoned vehicles",
                   "doors": "fence gates", "hazards": "sinkhole / unstable ground", "start": "supply depot",
                   "goal": "field hospital tent"},
        "map": [
            "########",
            "#S.....#",
            "#.##.#.#",
            "#X#..#X#",
            "#.D.^#.#",
            "#.#....#",
            "#...X.G#",
            "########",
        ],
        "shortcut_note": "The east lane would be fastest but a fallen tree blocks it. The middle road crosses a sinkhole, the west gate leads into a dead-end yard, and the safe route skirts the sinkhole to the west.",
    },
    {
        "id": "hazardous-research-building",
        "seed": 900005,
        "title": "Hazardous Research Building",
        "difficulty": "hard",
        "briefing": ("A fictional research building has had a chemical spill. Several lab doors are sealed and "
                     "a researcher is waiting in the clean room. Spill zones cover the shortest-looking routes."),
        "objective": "Reach the clean room without crossing a spill zone.",
        "legend": {"walls": "lab walls", "blocked": "sealed doors / equipment", "doors": "lab doors",
                   "hazards": "chemical spill", "start": "decontamination entrance", "goal": "clean room"},
        "map": [
            "##########",
            "#S.#....^#",
            "#..D.##^.#",
            "#^##.#G..#",
            "#..#.#B#.#",
            "#.D..#.#.#",
            "#.##.^.#.#",
            "#..#.#...#",
            "#^.....#.#",
            "##########",
        ],
        "shortcut_note": "The clean room's south door is sealed. Both the top corridor and the east approach have spills exactly where they look fastest; the safe route runs through the lower lab block and up the east corridor.",
    },
]


def parse_map(rows):
    h, w = len(rows), len(rows[0])
    assert all(len(r) == w for r in rows), "ragged map"
    cells = {"walls": [], "blocked": [], "hazards": [], "doors": []}
    start = goal = None
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            c = [x, y]
            if ch == "#":
                cells["walls"].append(c)
            elif ch == "X":
                cells["blocked"].append(c)
            elif ch == "^":
                cells["hazards"].append(c)
            elif ch == "D":
                cells["doors"].append(c)
            elif ch == "B":
                cells["doors"].append(c)
                cells["blocked"].append(c)
            elif ch == "S":
                start = c
            elif ch == "G":
                goal = c
            elif ch != ".":
                raise ValueError(f"unknown map char {ch!r}")
    return w, h, start, goal, cells


def bfs_len(sc: Scenario, obstacles):
    start, goal = tuple(sc.start), tuple(sc.goal)
    dist = {start: 0}
    q = deque([start])
    while q:
        c = q.popleft()
        if c == goal:
            return dist[c]
        for dx, dy in ACTIONS.values():
            n = (c[0] + dx, c[1] + dy)
            if sc.in_bounds(n) and n not in obstacles and n not in dist:
                dist[n] = dist[c] + 1
                q.append(n)
    return None


def analyse(sc: Scenario):
    safe = astar_path(sc)
    risky = astar_path(sc, allow_hazards=True)
    no_blocked = bfs_len(sc, sc.wall_set | sc.hazard_set)
    free = {(x, y) for x in range(sc.width) for y in range(sc.height)} - sc.obstacle_set - sc.hazard_set
    dead_ends = []
    for c in sorted(free):
        if c in (tuple(sc.start), tuple(sc.goal)):
            continue
        deg = sum((c[0] + dx, c[1] + dy) in free for dx, dy in ACTIONS.values())
        if deg == 1:
            dead_ends.append(list(c))
    path_cells = {tuple(p) for p in safe}
    hazards_adjacent_to_route = sorted(
        [list(hz) for hz in sc.hazard_set
         if any((hz[0] + dx, hz[1] + dy) in path_cells for dx, dy in ACTIONS.values())])
    return {
        "par": len(safe) - 1,
        "hazard_shortcut_length": len(risky) - 1,
        "hazard_shortcut_exists": len(risky) < len(safe),
        "length_if_blocked_cleared": no_blocked,
        "blocked_forces_detour": no_blocked is not None and no_blocked < len(safe) - 1,
        "dead_ends": dead_ends,
        "hazards_adjacent_to_par_route": hazards_adjacent_to_route,
        "doors": len(sc.doors),
    }


def build():
    out = []
    for m in MISSIONS:
        w, h, start, goal, cells = parse_map(m["map"])
        max_steps = w * h  # 64 / 100: tighter than the generator default round(1.5*w*h)
        d = {"version": 1, "seed": m["seed"], "width": w, "height": h, "start": start, "goal": goal,
             "walls": cells["walls"], "doors": cells["doors"], "blocked": cells["blocked"],
             "hazards": cells["hazards"], "max_steps": max_steps}
        sc = Scenario.from_dict(d)          # validates (bounds, overlaps, solvable)
        sc.validate(require_hazard_free_path=True)
        a = analyse(sc)
        path = astar_path(sc)
        scenario = sc.to_dict()
        mission = {
            "id": m["id"], "title": m["title"], "briefing": m["briefing"], "objective": m["objective"],
            "difficulty": m["difficulty"], "handcrafted": True, "generated": False,
            "map_size": f"{w}x{h}", "par": a["par"], "max_steps": max_steps,
            "legend": m["legend"], "map_ascii": m["map"],
            "map_ascii_legend": {"#": "walls", "X": "blocked", "^": "hazards", "D": "doors",
                                 "B": "blocked door (doors + blocked)", "S": "start", "G": "goal", ".": "floor"},
            "design_notes": m["shortcut_note"], "analysis": a, "controls": CONTROLS,
            "mechanics": "Identical to RescueEnv: no water flow, no spreading hazards, no physics. "
                         "Narrative labels are cosmetic only.",
            "disclaimer": DISCLAIMER,
        }
        out.append((m, {**scenario, "mission": mission}, path))
    return out


def dump(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="only validate and print the analysis")
    args = ap.parse_args()
    built = build()
    for m, d, path in built:
        a = d["mission"]["analysis"]
        print(f"{m['id']:30s} {d['width']}x{d['height']} par={a['par']:2d} hazard_shortcut={a['hazard_shortcut_length']} "
              f"blocked_detour={a['blocked_forces_detour']}({a['length_if_blocked_cleared']}) "
              f"dead_ends={len(a['dead_ends'])} doors={a['doors']} near_hazards={len(a['hazards_adjacent_to_par_route'])}")
        problems = [k for k in ("hazard_shortcut_exists",) if not a[k]]
        if not a["blocked_forces_detour"] and not a["dead_ends"]:
            problems.append("no blocked detour and no dead end")
        if problems:
            print("   PROBLEMS:", problems)
    if args.check:
        return 0
    index = {"format_version": 1, "disclaimer": DISCLAIMER, "missions": []}
    manifest = {
        "package": "@worldshift/rescue-play", "format_version": 1, "disclaimer": DISCLAIMER,
        "coordinate_system": COORDINATE_SYSTEM,
        "action_mapping": {str(k): {"name": ACTION_NAMES[k], "delta_xy": list(v)} for k, v in ACTIONS.items()},
        "rules": "Identical to rescue_sim RescueEnv (see README rules table); default rewards, hazard_terminates=true.",
        "missions": [],
    }
    for m, d, path in built:
        mid = m["id"]
        dump(ROOT / "missions" / f"{mid}.json", d)
        dump(ROOT / "data" / "rescue-play" / "missions" / f"{mid}.json", d)
        route = {"mission_id": mid, "seed": d["seed"], "par": len(path) - 1, "path": path,
                 "actions": path_to_actions(path), "action_names": [ACTION_NAMES[a] for a in path_to_actions(path)],
                 "source": "rescue_sim.astar_path (hazard-avoiding, deterministic tie-breaking)"}
        dump(ROOT / "data" / "rescue-play" / "routes" / f"{mid}_astar.json", route)
        entry = {"id": mid, "title": d["mission"]["title"], "difficulty": d["mission"]["difficulty"],
                 "map_size": d["mission"]["map_size"], "par": d["mission"]["par"], "max_steps": d["max_steps"],
                 "seed": d["seed"]}
        index["missions"].append({**entry, "file": f"{mid}.json"})
        manifest["missions"].append({**entry, "mission": f"missions/{mid}.json",
                                     "astar_route": f"routes/{mid}_astar.json"})
    dump(ROOT / "missions" / "index.json", index)
    dump(ROOT / "data" / "rescue-play" / "manifest.json", manifest)
    print(f"wrote {len(built)} missions")
    return 0


if __name__ == "__main__":
    sys.exit(main())
