// TS -> Python direction: generate random action sequences in TypeScript (dist/), run them with
// RescueEnvTS / replayEpisode and write fixtures/ts_runs.json for scripts/verify_ts_in_python.py.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { ROOT } from "./run_python.mjs";
import { RescueEnvTS, replayEpisode } from "../dist/index.js";

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const fx = JSON.parse(readFileSync(join(ROOT, "fixtures", "parity_fixtures.json"), "utf-8"));
const scenarios = [
  ...fx.cases.map((c) => [c.id, c.scenario]),
  ...fx.astar_only.map((a) => [a.id, a.scenario]),
];
const ODD = { goal: 12.345678901234, step: -0.123456789, collision: -0.98765432109, hazard: -4.4444444444449 };
const NAMES = ["up", "down", "left", "right"];
const runs = [];
let i = 0;
for (const [id, sc] of scenarios) {
  const rnd = mulberry32(1000 + i);
  const ht = i % 3 !== 0;
  const rc = i % 5 === 0 ? ODD : null;
  const n = (sc.max_steps ?? 100) + 5;
  const actions = Array.from({ length: n }, (_, k) => {
    const a = Math.floor(rnd() * 4);
    return k % 17 === 5 ? NAMES[a] : a; // mix in string actions
  });
  const opts = { hazardTerminates: ht, rewardConfig: rc ?? undefined };
  const env = new RescueEnvTS(sc, opts);
  for (const a of actions) {
    if (env.done) break;
    env.step(a);
  }
  runs.push({ id: `ts_${id}`, scenario: sc, hazard_terminates: ht, reward_config: rc, actions,
    ts_replay: replayEpisode(actions, sc, opts), ts_state: env.getState() });
  i++;
}
const steps = runs.reduce((s, r) => s + r.ts_replay.trajectory.length, 0);
writeFileSync(join(ROOT, "fixtures", "ts_runs.json"), JSON.stringify({ format_version: 1, producer: "scripts/gen_ts_runs.mjs", runs }));
console.log(`wrote fixtures/ts_runs.json: ${runs.length} runs, ${steps} steps`);
