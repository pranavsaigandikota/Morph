// Sample interactive session on "Cypress Lane Flood Response": restart, collision, hazard death,
// restart, suboptimal success. Writes samples/ (full state after every step) using dist/.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { ROOT } from "./run_python.mjs";
import { RescueGame, astarPath, pathToActions, replayEpisode } from "../dist/index.js";

const MISSION = "cypress-lane-flood";
const mission = JSON.parse(readFileSync(join(ROOT, "missions", `${MISSION}.json`), "utf-8"));
const game = new RescueGame(mission);
const events = [];
const attempts = [];
let current = [];

const snap = () => ({ state: game.getState(), metrics: game.metrics(), score: game.score() });
function press(key, note) {
  const res = game.step(key);
  current.push(res.info);
  events.push({ event: "step", input: key, note, result: res, ...snap() });
  if (game.done) endAttempt();
}
function endAttempt() {
  const exp = game.exportReplayInput();
  attempts.push({ attempt: attempts.length + 1, ...exp, outcome: game.getState().outcome,
    final_state: game.getState(), ts_replay: replayEpisode(exp.actions, exp.scenario, { hazardTerminates: exp.hazard_terminates }),
    score: game.score(), astar_comparison: game.compareWithAStar() });
}
function restart(note) {
  if (!game.done) endAttempt();
  game.restart();
  events.push({ event: "restart", note, ...snap() });
}

// Attempt 1: two moves, then restart
press("ArrowRight", "start east along the north road");
press("d", "WASD works too");
restart("player restarts to try the west street");
// Attempt 2: bump into a house, then take the flooded short cut
press("ArrowUp", "collision: house wall north of the launch point");
const risky = astarPath(mission, { allowHazards: true });
const riskyActions = pathToActions(risky);
for (const a of riskyActions) {
  if (game.done) break;
  press(["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"][a], "tempting short cut through the gardens");
}
restart("hazard death -> restart");
// Attempt 3: small detour (down 2, back up 2) then the safe route
for (const k of ["s", "s", "w", "w"]) press(k, "hesitation detour");
for (const a of pathToActions(astarPath(mission))) press(a, "safe route");

const final = attempts[attempts.length - 1];
mkdirSync(join(ROOT, "samples"), { recursive: true });
const write = (name, data) => writeFileSync(join(ROOT, "samples", name), JSON.stringify(data, null, 2) + "\n");
write(`session_${MISSION}.json`, {
  description: "Sample RescueGame session (TS port). Every event carries the full Python-shaped state after the step.",
  mission_id: MISSION, par: mission.mission.par, events, attempts: attempts.map(({ final_state, ts_replay, ...a }) => a),
});
write("session_score.json", {
  note: "Game-layer score (NOT part of the simulator contract); native reward is unchanged.",
  per_attempt: attempts.map((a) => ({ attempt: a.attempt, outcome: a.outcome, steps: a.actions.length,
    native_total_reward: a.final_state.cumulative_reward, collisions: a.final_state.collisions, score: a.score })),
  final_metrics: game.metrics(), final_score: game.score(),
});
write("session_astar_comparison.json", { mission_id: MISSION, final_attempt: final.astar_comparison,
  all_attempts: attempts.map((a) => ({ attempt: a.attempt, outcome: a.outcome, comparison: a.astar_comparison })) });
write("session_python_check_input.json", { format_version: 1, producer: "scripts/make_sample_session.mjs",
  runs: attempts.map((a) => ({ id: `session_attempt_${a.attempt}`, scenario: a.scenario,
    hazard_terminates: a.hazard_terminates, reward_config: a.reward_config, actions: a.actions,
    ts_replay: a.ts_replay, ts_state: a.final_state })) });
console.log(`session: ${events.length} events, attempts: ${attempts.map((a) => `${a.outcome}/${a.actions.length}`).join(", ")}, final score ${game.score().score}`);
