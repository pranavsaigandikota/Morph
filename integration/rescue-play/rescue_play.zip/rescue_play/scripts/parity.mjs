// npm run parity: regenerate Python fixtures, run the TS parity tests (python->ts), build,
// generate TS runs and verify them in Python (ts->python), and verify the sample session.
import { spawnSync } from "node:child_process";
import { join } from "node:path";
import { ROOT, runPython } from "./run_python.mjs";

function node(args) {
  const r = spawnSync(process.execPath, args, { cwd: ROOT, stdio: "inherit" });
  if (r.status !== 0) process.exit(r.status ?? 1);
}
function py(script, args = []) {
  const s = runPython(script, args);
  if (s !== 0) process.exit(s);
}
py("scripts/make_missions.py");
py("scripts/make_parity_fixtures.py");
node([join(ROOT, "node_modules", "typescript", "bin", "tsc"), "-p", "tsconfig.json"]);
node([join(ROOT, "node_modules", "vitest", "vitest.mjs"), "run"]);
node([join(ROOT, "scripts", "gen_ts_runs.mjs")]);
py("scripts/verify_ts_in_python.py");
node([join(ROOT, "scripts", "make_sample_session.mjs")]);
py("scripts/verify_ts_in_python.py", ["samples/session_python_check_input.json", "--out", "samples/session_python_verification.json"]);
console.log("PARITY OK (python->ts and ts->python)");
