"""Generate fixtures/parity_fixtures.json from the FROZEN Python rescue_sim (read-only).

    python scripts/make_parity_fixtures.py

Requires a Python where `rescue_sim` is importable (e.g. the rescue_sim venv).
Uses training seeds only (0-299) plus hand-made edge cases and the missions;
never the validation (10000-10099) or final-test (20000-20199) seeds.
"""
from __future__ import annotations

import json
import platform
import sys
from pathlib import Path

import numpy as np

import rescue_sim
from rescue_sim import RescueEnv, Scenario, astar_path, generate_scenario, path_to_actions, replay_episode
from rescue_sim.env import parse_action
from rescue_sim.scenario import ScenarioError

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "fixtures" / "parity_fixtures.json"
FORBIDDEN = [(10000, 10099), (20000, 20199)]


def box(w, h):
    return [[x, y] for y in range(h) for x in range(w) if x in (0, w - 1) or y in (0, h - 1)]


def run_sequence(scenario: dict, actions, hazard_terminates=True, reward_config=None, max_steps=None):
    env = RescueEnv(scenario=scenario, hazard_terminates=hazard_terminates, reward_config=reward_config,
                    max_steps=max_steps)
    _, reset_info = env.reset()
    steps, error = [], None
    for i, a in enumerate(actions):
        try:
            _, r, te, tr, info = env.step(a)
        except (RuntimeError, ValueError) as exc:
            error = {"index": i, "type": type(exc).__name__, "message": str(exc)}
            break
        steps.append({"reward": r, "terminated": te, "truncated": tr, "info": info})
    replay = None
    if max_steps is None:
        try:
            replay = replay_episode(actions, scenario, reward_config=reward_config,
                                    hazard_terminates=hazard_terminates)
        except ValueError as exc:  # invalid action in the list
            replay = {"error": {"type": type(exc).__name__, "message": str(exc)}}
    return {"actions": list(actions), "reset_info": reset_info, "steps": steps, "error": error,
            "final_state": env.get_state(), "replay": replay}


def seq(name, kind, scenario, actions, **kw):
    out = run_sequence(scenario, actions, **kw)
    out.update({"name": name, "kind": kind})
    return out


def case(cid, group, scenario: dict, sequences_spec, hazard_terminates=True, reward_config=None, max_steps=None):
    sc = Scenario.from_dict(scenario)
    seqs = [seq(n, k, scenario, a, hazard_terminates=hazard_terminates, reward_config=reward_config,
                max_steps=max_steps) for n, k, a in sequences_spec]
    return {"id": cid, "group": group, "scenario": scenario, "scenario_canonical": sc.to_dict(),
            "hazard_terminates": hazard_terminates,
            "reward_config": reward_config, "max_steps_override": max_steps,
            "astar": astar_path(sc), "astar_allow_hazards": astar_path(sc, allow_hazards=True), "sequences": seqs}


def rand_actions(seed, n):
    rng = np.random.default_rng(seed)
    return [int(a) for a in rng.integers(0, 4, size=n)]


def generated_cases():
    cases = []
    for w, h in ((8, 8), (10, 10)):
        for s in range(50):
            sc = generate_scenario(s, w, h).to_dict()
            ms = sc["max_steps"]
            astar_actions = path_to_actions(astar_path(sc))
            spec = [("astar", "astar", astar_actions),
                    ("astar_then_after_done", "after_done", astar_actions + [0, 1]),
                    ("random_a", "random", rand_actions(100000 + s * 7 + w, ms + 3)),
                    ("random_b", "random", rand_actions(200000 + s * 11 + w, ms + 3))]
            cases.append(case(f"gen_{w}x{h}_seed{s}", "generated", sc, spec))
            if s < 10:
                cases.append(case(f"gen_{w}x{h}_seed{s}_hazard_continue", "generated_hazard_continue", sc,
                                  [("random_long", "random", rand_actions(300000 + s, ms + 3)),
                                   ("astar_risky", "astar_allow_hazards",
                                    path_to_actions(astar_path(sc, allow_hazards=True)))],
                                  hazard_terminates=False))
            if s < 5:
                rc = {"goal": 7.77777777777, "step": 0.00048828125, "collision": -1.00048828125,
                      "hazard": -3.33333333335}
                cases.append(case(f"gen_{w}x{h}_seed{s}_odd_rewards", "custom_rewards", sc,
                                  [("random_odd", "random", rand_actions(400000 + s, ms + 3)),
                                   ("astar_odd", "astar", astar_actions)],
                                  hazard_terminates=bool(s % 2), reward_config=rc))
    return cases


def mission_cases():
    cases = []
    for p in sorted((ROOT / "missions").glob("*.json")):
        if p.name == "index.json":
            continue
        d = json.loads(p.read_text(encoding="utf-8"))
        sc = {k: v for k, v in d.items() if k != "mission"}
        safe = path_to_actions(astar_path(sc))
        risky = path_to_actions(astar_path(sc, allow_hazards=True))
        ms = sc["max_steps"]
        spec = [("astar", "astar", safe), ("astar_then_after_done", "after_done", safe + [3]),
                ("hazard_shortcut", "astar_allow_hazards", risky),
                ("random_a", "random", rand_actions(500000 + sc["seed"], ms + 3)),
                ("random_b", "random", rand_actions(600000 + sc["seed"], ms + 3))]
        cases.append(case(f"mission_{d['mission']['id']}", "mission", sc, spec))
        cases.append(case(f"mission_{d['mission']['id']}_hazard_continue", "mission_hazard_continue", sc,
                          [("hazard_shortcut", "astar_allow_hazards", risky)], hazard_terminates=False))
    return cases


def edge_cases():
    cases = []
    w5 = box(5, 5)
    corridor = {"seed": None, "width": 5, "height": 5, "start": [1, 1], "goal": [3, 3], "walls": w5,
                "hazards": [[2, 1]], "max_steps": 20}
    cases.append(case("edge_wall_collisions", "edge", corridor, [
        ("walls_and_strings", "scripted", [0, 2, 0, "up", "LEFT", " left ", 1, 1, 0, 2]),
        ("into_walls_then_goal", "scripted", [2, 2, 1, 1, 1, 3, 3]),
    ]))
    open5 = {"seed": None, "width": 5, "height": 5, "start": [0, 0], "goal": [4, 4], "walls": [],
             "hazards": [], "max_steps": 12}
    cases.append(case("edge_boundary_collisions", "edge", open5, [
        ("off_grid_top_left", "scripted", [0, 2, 0, 2, 3, 3, 3, 3, 3, 0, 1, 1]),
        ("off_grid_all_sides", "scripted", [1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 2, 0]),
    ]))
    cases.append(case("edge_hazard_termination", "edge", corridor, [
        ("step_on_hazard", "scripted", [3]),
        ("hazard_then_after_done", "after_done", [3, 3, "down"]),
        ("collision_then_hazard", "scripted", [0, 3]),
    ]))
    haz = {"seed": None, "width": 6, "height": 5, "start": [1, 2], "goal": [4, 2], "walls": box(6, 5),
           "hazards": [[2, 2], [3, 1], [3, 3]], "max_steps": 40}
    cases.append(case("edge_hazard_continue_repeated", "edge", haz, [
        ("back_and_forth", "scripted", [3, 2, 3, 2, 3, 2, 3, 3]),
        ("hazard_tour", "scripted", [3, 0, 3, 1, 1, 3, 0, 0, 2]),
    ], hazard_terminates=False))
    cases.append(case("edge_goal_reached", "edge", corridor, [
        ("down_down_right_right", "scripted", [1, 1, 3, 3]),
        ("goal_then_after_done", "after_done", [1, 1, 3, 3, 0]),
    ]))
    cases.append(case("edge_timeout", "edge", {**corridor, "max_steps": 5}, [
        ("collisions_until_timeout", "scripted", [0, 0, 0, 0, 0, 0]),
        ("moves_until_timeout", "scripted", [1, 0, 1, 0, 1, 1]),
    ]))
    cases.append(case("edge_goal_on_last_step", "edge", {**corridor, "max_steps": 4}, [
        ("exactly_max_steps", "scripted", [1, 1, 3, 3]),
    ]))
    cases.append(case("edge_goal_one_step_too_late", "edge", {**corridor, "max_steps": 4}, [
        ("one_collision_then_route", "scripted", [0, 1, 1, 3, 3]),
    ]))
    cases.append(case("edge_hazard_on_last_step_continue", "edge", {**haz, "max_steps": 3}, [
        ("hazard_at_limit", "scripted", [2, 1, 3]),
        ("hazard_at_limit_2", "scripted", [0, 0, 3]),
    ], hazard_terminates=False))
    cases.append(case("edge_max_steps_override", "edge", corridor, [
        ("override_3", "scripted", [0, 0, 0, 0]),
    ], max_steps=3))
    cases.append(case("edge_invalid_actions", "edge", corridor, [
        ("invalid_string", "invalid", [1, "jump", 0]),
        ("invalid_4", "invalid", [1, 4]),
        ("invalid_negative", "invalid", [-1]),
        ("invalid_bool", "invalid", [True]),
        ("invalid_float", "invalid", [1, 1.5]),
        ("invalid_null", "invalid", [None]),
        ("invalid_numeric_string", "invalid", ["0"]),
    ]))
    sc10 = generate_scenario(7, 10, 10).to_dict()
    cases.append(case("edge_long_random_hazard_continue", "edge", sc10, [
        ("long_random_150", "random", rand_actions(777, 160)),
        ("long_random_150_b", "random", rand_actions(778, 160)),
    ], hazard_terminates=False))
    tie_rc = {"goal": 0.00048828125, "step": -0.00048828125, "collision": 2.00048828125, "hazard": -0.00146484375}
    cases.append(case("edge_rounding_ties", "edge", {**corridor, "max_steps": 30}, [
        ("tie_collisions", "scripted", [0, 0, 2, 2, 0, 1, 1, 3, 3]),
    ], reward_config=tie_rc, hazard_terminates=False))
    return cases


def invalid_scenarios():
    base = {"seed": 42, "width": 10, "height": 10, "start": [1, 1], "goal": [8, 8],
            "walls": [[2, 1], [2, 2]], "hazards": [[5, 5]], "max_steps": 150}
    variants = {
        "start_out_of_bounds": {"start": [10, 1]}, "goal_negative": {"goal": [-1, 3]},
        "wall_out_of_bounds": {"walls": [[2, 1], [20, 2]]}, "hazard_out_of_bounds": {"hazards": [[5, 10]]},
        "start_on_wall": {"start": [2, 1]}, "goal_on_wall": {"goal": [2, 2]}, "goal_on_hazard": {"goal": [5, 5]},
        "start_on_hazard": {"start": [5, 5]}, "start_equals_goal": {"goal": [1, 1]},
        "hazard_overlaps_wall": {"hazards": [[2, 1]]}, "duplicate_walls": {"walls": [[2, 1], [2, 1]]},
        "too_small": {"width": 3}, "too_large": {"height": 65}, "width_string": {"width": "10"},
        "max_steps_zero": {"max_steps": 0}, "max_steps_negative": {"max_steps": -5},
        "start_short": {"start": [1]}, "start_float": {"start": [1.5, 1]}, "start_string": {"start": "1,1"},
        "start_bool": {"start": [True, 1]}, "blocked_overlaps_wall": {"blocked": [[2, 1]]},
        "start_on_blocked": {"blocked": [[1, 1]]}, "goal_on_blocked": {"blocked": [[8, 8]]},
        "blocked_overlaps_hazard": {"blocked": [[5, 5]]}, "door_overlaps_wall": {"doors": [[2, 2]]},
        "door_overlaps_hazard": {"doors": [[5, 5]]}, "walls_not_list": {"walls": "none"},
        "doors_null": {"doors": None}, "seed_string": {"seed": "abc"}, "seed_bool": {"seed": True},
        "start_enclosed_unsolvable": {"walls": [[1, 0], [0, 1], [1, 2], [2, 1]]},
        "goal_enclosed_unsolvable": {"walls": [[7, 8], [9, 8], [8, 7], [8, 9]]},
        "hazard_bad_cell": {"hazards": [[5]]}, "multi_overlap_sorted": {"hazards": [[3, 3], [2, 2], [2, 1]]},
    }
    out = []
    for name, ch in variants.items():
        d = {**base, **ch}
        out.append((name, d))
    out.append(("missing_max_steps", {k: v for k, v in base.items() if k != "max_steps"}))
    out.append(("missing_two_keys", {k: v for k, v in base.items() if k not in ("goal", "hazards")}))
    out.append(("not_a_dict", [1, 2, 3]))
    out.append(("valid_reference", base))
    res = []
    for name, d in out:
        try:
            Scenario.from_dict(d)
            res.append({"id": name, "data": d, "valid": True, "error": None})
        except ScenarioError as exc:
            res.append({"id": name, "data": d, "valid": False, "error": {"type": "ScenarioError", "message": str(exc)}})
    return res


def action_parsing():
    inputs = [0, 1, 2, 3, 4, -1, "up", "down", "left", "right", " Down ", "LEFT", "Right\n", "jump", "", "0",
              True, False, None, 1.5, [1]]
    out = []
    for x in inputs:
        try:
            out.append({"input": x, "action": parse_action(x), "error": None})
        except ValueError as exc:
            out.append({"input": x, "action": None, "error": str(exc)})
    return out


def rounding():
    rng = np.random.default_rng(12345)
    xs = [0.1 + 0.2, -0.1 - 1.0, -1.1, 9.9, -5.1, 1e-11, -1e-11, 5e-11, -5e-11, 0.00048828125, -0.00048828125,
          0.00146484375, -0.00146484375, 2.00048828125, 1.00048828125, -1.00048828125, 123456.00000000005,
          -0.30000000000000004, 0.0, -0.0, 1e-300, 12345678.123456789, 0.99999999995, -0.99999999995]
    xs += [float(k) * 2.0 ** -11 for k in range(-40, 41, 3)]          # many exact ties
    xs += [float(v) for v in rng.uniform(-200, 200, 300)]
    xs += [float(v) for v in rng.normal(0, 1e-6, 100)]
    acc, cum = 0.0, []
    for a in rng.choice([-0.1, -1.1, -5.1, 9.9], 400):
        acc += round(float(a), 10)
        cum.append(acc)
    xs += cum
    return [{"x": x, "rounded": float(round(x, 10))} for x in xs]


def astar_only():
    out = []
    for w, h in ((8, 8), (10, 10)):
        for s in range(100, 300):
            sc = generate_scenario(s, w, h)
            out.append({"id": f"astar_{w}x{h}_seed{s}", "scenario": sc.to_dict(), "astar": astar_path(sc),
                        "astar_allow_hazards": astar_path(sc, allow_hazards=True)})
    # unreachable goal through hazards only / fully enclosed by hazards
    sc = {"seed": None, "width": 5, "height": 5, "start": [1, 1], "goal": [3, 3],
          "walls": box(5, 5) + [[2, 1], [2, 3]], "hazards": [[2, 2]], "max_steps": 30}
    out.append({"id": "astar_hazard_only", "scenario": sc, "astar": astar_path(sc),
                "astar_allow_hazards": astar_path(sc, allow_hazards=True)})
    sc2 = {"seed": None, "width": 6, "height": 6, "start": [1, 1], "goal": [4, 4], "walls": box(6, 6),
           "hazards": [[3, 4], [4, 3], [3, 3]], "max_steps": 30}
    out.append({"id": "astar_goal_ringed_by_hazards", "scenario": sc2, "astar": astar_path(sc2),
                "astar_allow_hazards": astar_path(sc2, allow_hazards=True)})
    return out


def main() -> int:
    cases = generated_cases() + mission_cases() + edge_cases()
    for c in cases:
        s = c["scenario"].get("seed")
        if s is not None and any(lo <= s <= hi for lo, hi in FORBIDDEN):
            raise SystemExit(f"forbidden seed {s} in {c['id']}")
    data = {
        "fixture_format_version": 1,
        "generated_with": {"python": platform.python_version(), "numpy": np.__version__,
                           "rescue_sim": rescue_sim.__version__},
        "seed_policy": "training seeds 0-299 only (+ missions 900001-900005); no validation/final-test seeds",
        "cases": cases,
        "astar_only": astar_only(),
        "invalid_scenarios": invalid_scenarios(),
        "action_parsing": action_parsing(),
        "rounding": rounding(),
    }
    n_seq = sum(len(c["sequences"]) for c in cases)
    n_steps = sum(len(s["steps"]) for c in cases for s in c["sequences"])
    data["counts"] = {"cases": len(cases), "sequences": n_seq, "steps": n_steps,
                      "astar_only": len(data["astar_only"]), "invalid_scenarios": len(data["invalid_scenarios"]),
                      "action_parsing": len(data["action_parsing"]), "rounding": len(data["rounding"])}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data, separators=(",", ":"), allow_nan=False), encoding="utf-8", newline="\n")
    print(f"wrote {OUT.relative_to(ROOT).as_posix()} ({OUT.stat().st_size // 1024} KiB): {data['counts']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
