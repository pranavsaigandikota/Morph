// SMOKE-TEST DEMO ONLY - not the WorldShift frontend. Vanilla TS, zero dependencies.
import { RescueGame, createStepController } from "../dist/index.js";
const MANIFEST_URL = new URL("../data/rescue-play/manifest.json", window.location.href);
const canvas = document.getElementById("map");
const ctx = canvas.getContext("2d");
const select = document.getElementById("mission");
const hud = document.getElementById("hud");
const briefing = document.getElementById("briefing");
const dpad = Array.from(document.querySelectorAll("#dpad button[data-action]"));
const restartBtn = document.getElementById("restart");
let game = null;
let ctl = null;
let mission = null;
const FLASH_MS = 350; // brief collision feedback (visual only), timed by the controller
const CELL = 48;
async function loadManifest() {
    const m = await (await fetch(MANIFEST_URL)).json();
    for (const e of m.missions) {
        const o = document.createElement("option");
        o.value = new URL(e.mission, MANIFEST_URL).toString();
        o.textContent = `${e.title} (${e.map_size}, par ${e.par})`;
        select.appendChild(o);
    }
    select.onchange = () => loadMission(select.value);
    await loadMission(select.value);
}
async function loadMission(url) {
    mission = await (await fetch(url)).json();
    game = new RescueGame(mission);
    ctl?.dispose();
    // CONTROL CONTRACT (t17u): tap = 1 step, hold = repeat every 200 ms, see CONTROL_CONTRACT.md
    ctl = createStepController(game, {
        holdRepeatMs: 200,
        collisionFlashMs: FLASH_MS,
        // keep arrows for the mission <select> while it has focus
        isActive: () => !(document.activeElement instanceof HTMLSelectElement),
        onChange: () => draw(), // steps, hold steps, restart, undo, A* toggle and flash_end all redraw
    });
    canvas.width = mission.width * CELL;
    canvas.height = mission.height * CELL;
    briefing.textContent = `${mission.mission.briefing} Objective: ${mission.mission.objective}`;
    draw();
}
const has = (cells, x, y) => cells.some((c) => c[0] === x && c[1] === y);
function draw() {
    if (!game)
        return;
    const s = game.getState();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let y = 0; y < s.height; y++) {
        for (let x = 0; x < s.width; x++) {
            let color = "#e8e4d8";
            if (has(s.walls, x, y))
                color = "#3b3b3b";
            else if (has(s.blocked, x, y))
                color = "#8a5a2b";
            else if (has(s.hazards, x, y))
                color = "#2f7bd8";
            else if (has(s.doors, x, y))
                color = "#c9b77a";
            ctx.fillStyle = color;
            ctx.fillRect(x * CELL, y * CELL, CELL - 1, CELL - 1);
        }
    }
    const mark = (c, color, label) => {
        ctx.fillStyle = color;
        ctx.fillRect(c[0] * CELL + 6, c[1] * CELL + 6, CELL - 13, CELL - 13);
        ctx.fillStyle = "#fff";
        ctx.font = "bold 16px sans-serif";
        ctx.fillText(label, c[0] * CELL + 17, c[1] * CELL + 30);
    };
    mark(s.start, "#777", "S");
    mark(s.goal, "#2e9d4a", "G");
    const route = (cells, color, off) => {
        ctx.strokeStyle = color;
        ctx.lineWidth = 4;
        ctx.beginPath();
        cells.forEach((c, i) => {
            const px = c[0] * CELL + CELL / 2 + off;
            const py = c[1] * CELL + CELL / 2 + off;
            if (i === 0)
                ctx.moveTo(px, py);
            else
                ctx.lineTo(px, py);
        });
        ctx.stroke();
    };
    const cmp = game.compareWithAStar();
    route(cmp.player_route, "rgba(220,60,60,0.8)", -4);
    if (ctl?.showAStar && cmp.astar_route)
        route(cmp.astar_route, "rgba(30,160,60,0.9)", 4);
    ctx.fillStyle = "#d33";
    ctx.beginPath();
    ctx.arc(s.agent[0] * CELL + CELL / 2, s.agent[1] * CELL + CELL / 2, CELL / 3, 0, Math.PI * 2);
    ctx.fill();
    if (ctl?.collisionFlash) {
        // visual-only feedback for a blocked move (no rule change)
        ctx.strokeStyle = "#ff9800";
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(s.agent[0] * CELL + CELL / 2, s.agent[1] * CELL + CELL / 2, CELL / 2.3, 0, Math.PI * 2);
        ctx.stroke();
    }
    const m = game.metrics();
    const sc = game.score();
    hud.textContent = [
        `step ${m.steps}/${s.max_steps}   collisions ${m.collisions}   hazards ${m.hazards_entered}   restarts ${m.restarts}`,
        `native reward ${m.native_total_reward}   outcome ${m.outcome ?? "in progress"}`,
        sc.status === "success" ? `SCORE ${sc.score}  ${"★".repeat(sc.stars)}  (A* par ${cmp.optimal_length}, you ${cmp.player_steps})` :
            sc.status === "failure" ? `FAILED (${sc.reason}) - press R to restart` : "",
        s.done ? "Press H to toggle the A* route. Movement is disabled until Restart." :
            "Arrows/WASD: tap = 1 step, hold = repeat (~5/s). D-pad: 1 step per click. R restart, U undo",
    ].join("\n");
    for (const b of dpad)
        b.disabled = s.done; // Restart stays enabled
}
window.addEventListener("keydown", (ev) => ctl?.handleKeyDown(ev));
window.addEventListener("keyup", (ev) => ctl?.handleKeyUp(ev));
window.addEventListener("blur", () => ctl?.handleBlur());
document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden")
        ctl?.handleVisibilityHidden();
});
for (const b of dpad)
    b.addEventListener("click", () => ctl?.press(Number(b.dataset.action)));
restartBtn.addEventListener("click", () => ctl?.restart());
loadManifest().catch((e) => (hud.textContent = `Failed to load: ${e}. Serve the rescue_play folder over HTTP.`));
