// SMOKE-TEST DEMO ONLY - not the WorldShift frontend. Vanilla TS, zero dependencies.
import { RescueGame, keyToAction, type Cell } from "../dist/index.js";

const MANIFEST_URL = new URL("../data/rescue-play/manifest.json", window.location.href);
const canvas = document.getElementById("map") as HTMLCanvasElement;
const ctx = canvas.getContext("2d") as CanvasRenderingContext2D;
const select = document.getElementById("mission") as HTMLSelectElement;
const hud = document.getElementById("hud") as HTMLPreElement;
const briefing = document.getElementById("briefing") as HTMLParagraphElement;
let game: RescueGame | null = null;
let mission: any = null;
let showAStar = false;
const CELL = 48;

async function loadManifest() {
  const m = await (await fetch(MANIFEST_URL)).json();
  for (const e of m.missions) {
    const o = document.createElement("option");
    o.value = new URL(e.mission, MANIFEST_URL).toString();
    o.textContent = `${e.title} (${e.map_size}, par ${e.par})`;
    select.appendChild(o);
  }
  select.onchange = () => loadMission(select.value);
  await loadMission(select.value);
}

async function loadMission(url: string) {
  mission = await (await fetch(url)).json();
  game = new RescueGame(mission);
  showAStar = false;
  canvas.width = mission.width * CELL;
  canvas.height = mission.height * CELL;
  briefing.textContent = `${mission.mission.briefing} Objective: ${mission.mission.objective}`;
  draw();
}

const has = (cells: Cell[], x: number, y: number) => cells.some((c) => c[0] === x && c[1] === y);

function draw() {
  if (!game) return;
  const s = game.getState();
  for (let y = 0; y < s.height; y++) {
    for (let x = 0; x < s.width; x++) {
      let color = "#e8e4d8";
      if (has(s.walls, x, y)) color = "#3b3b3b";
      else if (has(s.blocked, x, y)) color = "#8a5a2b";
      else if (has(s.hazards, x, y)) color = "#2f7bd8";
      else if (has(s.doors, x, y)) color = "#c9b77a";
      ctx.fillStyle = color;
      ctx.fillRect(x * CELL, y * CELL, CELL - 1, CELL - 1);
    }
  }
  const mark = (c: Cell, color: string, label: string) => {
    ctx.fillStyle = color;
    ctx.fillRect(c[0] * CELL + 6, c[1] * CELL + 6, CELL - 13, CELL - 13);
    ctx.fillStyle = "#fff";
    ctx.font = "bold 16px sans-serif";
    ctx.fillText(label, c[0] * CELL + 17, c[1] * CELL + 30);
  };
  mark(s.start, "#777", "S");
  mark(s.goal, "#2e9d4a", "G");
  const route = (cells: Cell[], color: string, off: number) => {
    ctx.strokeStyle = color;
    ctx.lineWidth = 4;
    ctx.beginPath();
    cells.forEach((c, i) => {
      const px = c[0] * CELL + CELL / 2 + off;
      const py = c[1] * CELL + CELL / 2 + off;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.stroke();
  };
  const cmp = game.compareWithAStar();
  route(cmp.player_route, "rgba(220,60,60,0.8)", -4);
  if (showAStar && cmp.astar_route) route(cmp.astar_route, "rgba(30,160,60,0.9)", 4);
  ctx.fillStyle = "#d33";
  ctx.beginPath();
  ctx.arc(s.agent[0] * CELL + CELL / 2, s.agent[1] * CELL + CELL / 2, CELL / 3, 0, Math.PI * 2);
  ctx.fill();
  const m = game.metrics();
  const sc = game.score();
  hud.textContent = [
    `step ${m.steps}/${s.max_steps}   collisions ${m.collisions}   hazards ${m.hazards_entered}   restarts ${m.restarts}`,
    `native reward ${m.native_total_reward}   outcome ${m.outcome ?? "in progress"}`,
    sc.status === "success" ? `SCORE ${sc.score}  ${"★".repeat(sc.stars)}  (A* par ${cmp.optimal_length}, you ${cmp.player_steps})` :
      sc.status === "failure" ? `FAILED (${sc.reason}) - press R to restart` : "",
    s.done ? "Press H to toggle the A* route." : "Arrows/WASD move, R restart, U undo",
  ].join("\n");
}

window.addEventListener("keydown", (ev) => {
  if (!game) return;
  const k = ev.key.toLowerCase();
  if (k === "r") game.restart();
  else if (k === "u" || k === "backspace") game.undo();
  else if (k === "h") showAStar = game.done ? !showAStar : false;
  else {
    const a = keyToAction(ev.key);
    if (a === null || game.done) return;
    game.step(a);
  }
  ev.preventDefault();
  draw();
});

loadManifest().catch((e) => (hud.textContent = `Failed to load: ${e}. Serve the rescue_play folder over HTTP.`));
