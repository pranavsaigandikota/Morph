export default { test: { include: ["test/**/*.test.ts"], testTimeout: 120000 } };
