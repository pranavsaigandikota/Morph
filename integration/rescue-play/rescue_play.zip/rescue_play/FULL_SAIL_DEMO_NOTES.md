# Rescue Play: Demo Notes (Full Sail: Pathways & Perception)

*Also relevant to Best Game Hack and Best AI Hack. Knight Hacks IX.*

## What it is

Rescue Play is a browser-playable grid game built on our frozen Python rescue-navigation
simulator (`rescue_sim`). The player (or an agent) moves one cell at a time (up, down, left,
right) to reach an exit. The map has walls, doors, debris and hazards. The TypeScript game
reproduces the Python simulator's rules exactly, and it ships an A\* planner so the player can
see the optimal route after each attempt. It is a structured grid simulation with no physics,
no world model and no AI-generated video.

## Why rescue navigation needs pathfinding

A building or a flooded block is not open ground. Walls and debris cut off the straight line to
the exit, doors are the only way between rooms, and some cells are dangerous to enter. Moving
"towards the goal" therefore often runs into a dead end or a hazard. A good route needs a
**search over reachable cells**, not a straight line.

**A\*** does this search. It expands cells in order of `steps so far + estimated steps left`,
where the estimate is the **Manhattan distance** `|dx| + |dy|`. On a 4-connected grid where
every move costs 1, that estimate never overestimates, so A\* returns a **shortest path**. Ties
are broken deterministically (lowest estimate first, then row and column order, with neighbours
expanded up, down, left, right), so the same map always gives the same route in Python and in
the browser. The game uses the **hazard-avoiding variant**: walls and debris are never crossed,
and hazards are treated as off-limits. If no safe route exists it returns "no path" and does not
fall back to a dangerous one.

## How walls, hazards and blocked routes change decisions

The rules are the frozen simulator's (unchanged):

| event | effect | reward that step |
|---|---|---|
| normal move | move one cell | -0.1 |
| bump into a wall, debris or the edge | stay in place, the step is still used | -1.1 (-0.1 step, -1.0 collision) |
| step onto a hazard | episode ends, outcome "hazard" | -5.1 (-0.1 step, -5.0 hazard) |
| reach the exit | episode ends, outcome "success" | +9.9 (-0.1 step, +10 goal) |
| run out of steps (`max_steps`) | episode ends, outcome "timeout" | - |

Every mission is designed so that the obvious choice is wrong. There is a **hazard shortcut
shorter than par**, and **debris forces a detour** (the route would be shorter if the blocked
cells were clear):

| mission | size | par (safe A\*) | shortest route through hazards | shortest safe route if debris were cleared |
|---|---|---|---|---|
| Cypress Lane Flood Response | 10x10 | 16 | 14 | 14 |
| Storm-Damaged Facility Sweep | 10x10 | 21 | 15 | 9 |
| Blocked Evacuation Corridor | 8x8 | 13 | 9 | 5 |
| Emergency Supply Route | 8x8 | 12 | 10 | 10 |
| Hazardous Research Building | 10x10 | 21 | 11 | 17 |

For example, on Cypress Lane the route across flooded streets is 2 steps shorter than par, but
it ends the episode. The safe route takes the long way around a stalled car.

## How the player is compared with A\*

After an attempt the game reports:

* **par**: the length of the hazard-avoiding A\* route;
* **player steps**: including steps lost to collisions;
* **efficiency** = A\* length / player steps (1.0 = optimal; successful attempts only);
* **first divergence step**: the first step where the player's position differs from the A\* route;
* a **route overlay** drawing the player's route and the A\* route as cell lists.

**Score (game layer only):** on success, `max(0, round(1000 x A* length / steps) - 50 x collisions)`.
Stars: 3 if efficiency is at least 1.0, 2 if at least 0.8, otherwise 1. On a hazard or timeout,
the score is 0 with the reason shown. The score is a game metric for players. It is **not part
of the simulator contract**, and the native simulator reward is reported unchanged next to it.
In our recorded sample session on Cypress Lane, a 20-step success against par 16 gives
efficiency 0.8, score 800 and 2 stars.

## What was measured and verified

**Rescue Play (TypeScript port):**

* 208 automated tests pass (176 engine, parity and game tests, 13 controls tests and 19 hold-to-repeat controls tests).
* Python to TypeScript parity: 153 scenarios, 518 action sequences, 17,842 steps; 0 mismatches.
* TypeScript to Python parity: 555 runs, 40,846 steps; 0 mismatches.
* 1,110 A\* paths identical in both languages.
* Rerun on Arnov's Windows PC (Node 22.17.1) with the same result.

**Agents on the frozen simulator:** 200 held-out maps per size (seeds 20000-20199), success rate:

| map | Random | guided PPO | A\* |
|---|---|---|---|
| 8x8 | 19.5% | 99.5% | 100% |
| 10x10 | 8.0% | 99.0% | 100% |

These results were independently reproduced exactly.

**Important caveat:** the guided PPO network includes a hand-coded BFS "closer to exit"
feature. Its near-A\* score reflects that design choice; it is not evidence of purely learned
navigation.

### Unguided PPO (no shortest-path hint): verified

The unguided PPO model gets **no shortest-path hint**: its feature extractor contains no search
or planner code, and a planner trap never fired during evaluation. It was evaluated with the
frozen simulator and native rewards, and independently verified (40/40 checks). Success rate on
200 maps per size and split:

<!-- UNGUIDED_RESULTS -->
| seeds | map | Random | Unguided PPO | Guided PPO (BFS hint) | A\* |
|---|---|---|---|---|---|
| 20000-20199 | 8x8 | 19.5% | **66.0%** | 99.5% | 100% |
| 20000-20199 | 10x10 | 8.0% | **55.0%** | 99.0% | 100% |
| 30000-30199 | 8x8 | 13.5% | **72.5%** | 99.0% | 100% |
| 30000-30199 | 10x10 | 15.0% | **52.0%** | 98.5% | 100% |

On seeds 20000-20199, **every unguided PPO failure was a timeout**: it never entered a hazard
and never collided. When it succeeded, its routes were near-optimal (path efficiency vs A\*
0.99). Seeds 20000-20199 are the protocol's final-test set, which had already been used to
evaluate guided PPO, so they are not untouched for this comparison. Seeds 30000-30199 are a fresh
supplementary held-out block, scored once. Neither PPO model was trained or selected on either
block. Source: `unguided_ppo_handoff.zip` → `comparison.json`. The Random, 30000-block guided
PPO and A\* values are from the same file.

### Browser playtest

<!-- BROWSER_RESULTS -->
The smoke-test demo was checked in three passes. Full details are in `BROWSER_VALIDATION.md`.

* **Pass 1** (Playwright synthetic keys, not OS-level): all 5 missions played; gameplay, scores,
  restarts and the A\* comparison worked. It found 3 demo issues (leftover route dots after
  restart, no collision feedback, OS auto-repeat consuming steps), all fixed.
* **Pass 2** (real OS keystrokes, Chromium + DevTools, earlier one-step build): on Cypress Lane
  and Hazardous Research Building it showed the collision ring, hazard failure, clean restart,
  success **1000 ★★★** with WASD, a **905 ★★** success, and the A\* overlay. Arrows work with
  the mission dropdown focused. No clipping at 1366x768 and 1920x1080. The console was clean
  apart from a favicon 404, since fixed. The A\* overlay persisting after R was also fixed.
  Video: `qa/gameplay_os_keys_2x.mp4`.
* **Final pass** (real OS keys and mouse clicks, final tap + hold controller, Blocked Evacuation
  Corridor): tap, D-pad one step per click, undo, hazard lock (inputs ignored, buttons disabled),
  restart and no page scroll all PASS. Video: `qa/final_controls_pass_os_input.mp4`.
* **Hold-to-repeat has not been verified by a human with a physical keyboard.** The OS tool
  cannot hold keys. Automated CDP-level browser tests (a 1 s hold gives 6 steps and 0 after
  release; holding into a wall gives 1 collision, then the hold stops) and unit tests passed. A
  manual physical-key check is recommended but has not been done.

## Possible educational use (not proven)

The fictional scenarios **could** support emergency-preparedness education, for example:

* practising route planning under constraints (blocked routes, limited steps);
* recognising that the shortest-looking route may be unsafe;
* comparing your own choices with an optimal planner, step by step;
* discussing trade-offs (speed vs. risk, detours vs. dead ends).

We have **no learning-outcome data** and make **no claims of training efficacy**.

## 60-90 second demo script

1. **(10 s)** Open the game and pick *Cypress Lane Flood Response* (10x10, par 16). Read the
   one-line objective: reach the community shelter without entering a flooded street.
2. **(15 s)** Bump a wall once: the agent stays put and loses 1.1. Then take the tempting short
   cut through the flooded street: the episode ends with "hazard" and score 0.
3. **(5 s)** Press R to restart; the restart counter goes up.
4. **(25 s)** Walk the long way round the stalled car to the shelter: "success", with score and stars.
5. **(15 s)** Show the A\* overlay: par vs. your steps, efficiency, and the first step where you diverged.
6. **(15 s)** Show the evaluation table: Random vs. guided PPO vs. A\* on 200 held-out maps
   per size, and state the BFS-feature caveat for guided PPO.

## Limitations and honesty notes

* Grid abstraction with 4-way moves; no physics, water flow, spreading hazards or timing.
* All scenarios are fictional and hand-designed; the five missions are small (8x8 and 10x10).
* Not a validated emergency-response training tool; not for operational use.
* The score and stars are game metrics, not simulator rewards or safety measures.
* Guided PPO results depend on a hand-coded path feature (see caveat above). Unguided PPO
  (no hint) reaches 52-72.5% depending on split and size, failing only by timeout.
* Browser playtests used automation (synthetic, OS-level and CDP-level input). Physical-keyboard
  hold-to-repeat has not been verified by a human.
* Mission disclaimer (verbatim, shipped in every mission file): *"Fictional scenario. A discrete
  grid abstraction for gameplay and evaluation only; it is not representative of real-world
  flood, storm, structural or chemical behaviour and must not be used for operational planning
  or emergency response."*
